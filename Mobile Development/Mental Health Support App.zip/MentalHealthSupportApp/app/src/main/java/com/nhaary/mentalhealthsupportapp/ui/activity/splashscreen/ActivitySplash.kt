package com.nhaary.mentalhealthsupportapp.ui.activity.splashscreen

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.nhaary.mentalhealthsupportapp.MainActivity
import com.nhaary.mentalhealthsupportapp.R

class ActivitySplash : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_splashscreen)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val logoSplash: ImageView = findViewById(R.id.logo_splash)
        animateLogoSplash(logoSplash)

    }
    private fun animateLogoSplash(logoSplash: ImageView) {
        val fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in)
        logoSplash.startAnimation(fadeIn)

        fadeIn.setAnimationListener(object : Animation.AnimationListener{
            override fun onAnimationStart(animasi: Animation?) {
            }
            override fun onAnimationEnd(animasi: Animation?) {
                Handler().postDelayed({
                    val intent = Intent(this@ActivitySplash, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                }, 1000)

            }

            override fun onAnimationRepeat(animasi: Animation?) {
                TODO("Not yet implemented")
            }
        })


    }
}