package com.nhaary.mentalhealthsupportapp.ui.customview

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import android.util.Patterns
import androidx.appcompat.widget.AppCompatEditText
import com.google.android.material.textfield.TextInputLayout
import com.nhaary.mentalhealthsupportapp.R

class EmailFieldInput @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : AppCompatEditText(context, attrs) {

    init {
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val emailLayout = generateSequence(parent) { it.parent }.find { it is TextInputLayout } as? TextInputLayout
                val email = s.toString()
                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches() && email.isNotEmpty()) {
                    emailLayout?.error = context.getString(R.string.email_error)
                } else {
                    emailLayout?.error = null
                }
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })
    }

}