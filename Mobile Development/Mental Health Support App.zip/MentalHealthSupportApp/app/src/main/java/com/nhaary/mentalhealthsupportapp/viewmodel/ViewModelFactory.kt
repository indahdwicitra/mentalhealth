package com.nhaary.mentalhealthsupportapp.viewmodel

import android.annotation.SuppressLint
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.nhaary.mentalhealthsupportapp.data.repository.ArticleRepository
import com.nhaary.mentalhealthsupportapp.data.repository.AuthRepository
import com.nhaary.mentalhealthsupportapp.data.repository.HistoryRepository
import com.nhaary.mentalhealthsupportapp.di.Injection
import com.nhaary.mentalhealthsupportapp.helper.SettingPreferences
import com.nhaary.mentalhealthsupportapp.ui.activity.detailarticle.DetailArticleViewModel
import com.nhaary.mentalhealthsupportapp.ui.activity.signin.SignInViewModel
import com.nhaary.mentalhealthsupportapp.ui.activity.signup.SignUpViewModel
import com.nhaary.mentalhealthsupportapp.ui.favorite.FavoriteViewModel
import com.nhaary.mentalhealthsupportapp.ui.history.HistoryViewModel
import com.nhaary.mentalhealthsupportapp.ui.home.HomeViewModel
import com.nhaary.mentalhealthsupportapp.ui.setting.SettingViewModel

class ViewModelFactory private constructor(
    private val authRepository: AuthRepository,
    private val articleRepository: ArticleRepository,
    private val historyRepository: HistoryRepository,
    private val pref: SettingPreferences
): ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(SettingViewModel::class.java) -> SettingViewModel(pref) as T
            modelClass.isAssignableFrom(HomeViewModel::class.java) -> HomeViewModel(articleRepository) as T
            modelClass.isAssignableFrom(HistoryViewModel::class.java) -> HistoryViewModel(historyRepository) as T
            modelClass.isAssignableFrom(DetailArticleViewModel::class.java) -> DetailArticleViewModel(articleRepository) as T
            modelClass.isAssignableFrom(SignUpViewModel::class.java) -> SignUpViewModel(authRepository) as T
            modelClass.isAssignableFrom(SignInViewModel::class.java) -> SignInViewModel(authRepository) as T
            modelClass.isAssignableFrom(FavoriteViewModel::class.java) -> FavoriteViewModel(articleRepository) as T
            else -> throw IllegalArgumentException("ViewModel Tidak diketahui")
        }
    }
    companion object {
        @SuppressLint("StaticFieldLeak")
        @Volatile
        private var instance: ViewModelFactory? = null
        fun getInstance(context: Context): ViewModelFactory {
            return instance ?: synchronized(this) {
                instance ?: ViewModelFactory(
                    Injection.provideAuthRepository(),
                    Injection.provideArticleRepository(context),
                    Injection.provideHistoryRepository(context),
                    Injection.providePreferences(context)
                ).also { instance = it }
            }
        }
    }
}