package com.nhaary.mentalhealthsupportapp.ui.resultdiagnose

import androidx.fragment.app.viewModels
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.data.database.HistoryDatabase
import com.nhaary.mentalhealthsupportapp.data.database.HistoryEntity
import com.nhaary.mentalhealthsupportapp.databinding.FragmentResultDiagnoseBinding
import com.nhaary.mentalhealthsupportapp.ui.filljurnal.FillJurnalFragment.Companion.DIAGNOSE_DATE_KEY
import com.nhaary.mentalhealthsupportapp.ui.filljurnal.FillJurnalFragment.Companion.INFERENCE_TIME_KEY
import com.nhaary.mentalhealthsupportapp.ui.filljurnal.FillJurnalFragment.Companion.JOURNAL_KEY
import com.nhaary.mentalhealthsupportapp.ui.filljurnal.FillJurnalFragment.Companion.RESULT_KEY
import com.nhaary.mentalhealthsupportapp.ui.fillpersonality.FillPersonalityFragment
import kotlinx.coroutines.launch

class ResultDiagnoseFragment : Fragment() {

    private var _binding: FragmentResultDiagnoseBinding? = null
    private val binding get() = _binding!!

    private val viewModel: ResultDiagnoseViewModel by viewModels()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentResultDiagnoseBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val resultText = arguments?.getString(RESULT_KEY) ?: "No result available"
        val inferenceTime = arguments?.getLong(INFERENCE_TIME_KEY) ?: 0L
        val diagnoseDate = arguments?.getString(DIAGNOSE_DATE_KEY) ?: "Unknown Date"
        val complaintData = arguments?.getString(JOURNAL_KEY) ?: "Nothing Complaint Data"

        val percentageText = resultText.substringBefore("\nPredicted Stress Level:").trim()
        val predictedStressLevel = resultText.substringAfter("\nPredicted Stress Level:").trim()

        saveHistoryToDatabase(percentageText, predictedStressLevel, diagnoseDate, inferenceTime, complaintData)

        val inferenceString = getString(R.string.title_inference_time, inferenceTime)
        val stressLevelString = getString(R.string.predicted_stress_level, predictedStressLevel)
        val diagnoseDateString = getString(R.string.diagnose_date, diagnoseDate)

        with(binding) {
            resultDiagnose.text = percentageText
            stressLevel.text =  stressLevelString
            resultInferenceTime.text = inferenceString
            resultDate.text = diagnoseDateString

            if (predictedStressLevel.equals("no stress", ignoreCase = true)) {
                imageIdentification.setImageResource(R.drawable.image_happy)
                btnFinish.visibility = View.VISIBLE
                btnResultDiagnose.visibility = View.GONE

                btnFinish.setOnClickListener {
                    requireActivity().finish()
                }
            } else {
                imageIdentification.setImageResource(R.drawable.image_stress)
                btnFinish.visibility = View.GONE
                btnResultDiagnose.visibility = View.VISIBLE

                btnResultDiagnose.setOnClickListener {
                    val fillPersonality = FillPersonalityFragment()
                    parentFragmentManager.beginTransaction()
                        .replace(R.id.fragment_container, fillPersonality)
                        .addToBackStack(null)
                        .commit()
                }
            }
        }
    }

    private fun saveHistoryToDatabase(percentageText: String, predictedStressLevel: String, diagnoseDate: String, inferenceTime: Long, complaintData: String) {
        val historyDatabase = HistoryDatabase.getDatabase(requireContext())
        val history = HistoryEntity (
            dataPercentage = percentageText,
            levelStress = predictedStressLevel,
            date = diagnoseDate,
            inferenceTime = inferenceTime.toString(),
            complaintData = complaintData

        )
        lifecycleScope.launch {
            val totalDataHistory = historyDatabase.historyDao().getHistoryCount()

            if (totalDataHistory >= 10) {
                historyDatabase.historyDao().deleteOldHistory()
            }

            historyDatabase.historyDao().insertHistory(history)
        }
    }
}