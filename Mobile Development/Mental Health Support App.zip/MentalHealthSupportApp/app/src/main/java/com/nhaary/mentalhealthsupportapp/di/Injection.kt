package com.nhaary.mentalhealthsupportapp.di

import android.content.Context
import com.nhaary.mentalhealthsupportapp.data.database.HistoryDatabase
import com.nhaary.mentalhealthsupportapp.data.remote.retrofit.ApiConfig
import com.nhaary.mentalhealthsupportapp.data.repository.ArticleRepository
import com.nhaary.mentalhealthsupportapp.data.repository.AuthRepository
import com.nhaary.mentalhealthsupportapp.data.repository.HistoryRepository
import com.nhaary.mentalhealthsupportapp.helper.SettingPreferences
import com.nhaary.mentalhealthsupportapp.helper.dataStore

object Injection {

    private fun provideDatabase(context: Context): HistoryDatabase {
        return HistoryDatabase.getDatabase(context)
    }

    fun providePreferences(context: Context): SettingPreferences {
        return SettingPreferences.getInstance(context.dataStore)
    }

    fun provideArticleRepository(context: Context): ArticleRepository {
        val apiService = ApiConfig.getApiService()
        val database = HistoryDatabase.getDatabase(context)
        val dao = database.articleDao()
        return ArticleRepository.getInstance(apiService, dao)
    }

    fun provideHistoryRepository(context: Context): HistoryRepository {
        val database = provideDatabase(context)
        return HistoryRepository(database.historyDao())
    }

    fun provideAuthRepository(): AuthRepository {
        val apiService = ApiConfig.getLoginApiService()
        return AuthRepository(apiService)
    }

}