package com.nhaary.mentalhealthsupportapp.data.remote.retrofit

import androidx.lifecycle.LiveData
import com.nhaary.mentalhealthsupportapp.data.remote.response.ArticleDetailResponse
import com.nhaary.mentalhealthsupportapp.data.remote.response.ArticleResponse
import com.nhaary.mentalhealthsupportapp.data.remote.response.LoginRequest
import com.nhaary.mentalhealthsupportapp.data.remote.response.LoginResponse
import com.nhaary.mentalhealthsupportapp.data.remote.response.RegisterRequest
import com.nhaary.mentalhealthsupportapp.data.remote.response.RegisterResponse
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {
    @GET("articles")
    fun getArticles(): Call<ArticleResponse>

    @GET("articles/{id}")
    suspend fun getArticleDetails(@Path("id") articleId: Int): Response<ArticleDetailResponse>

    @POST("api/auth/register")
    fun registerUser(@Body request: RegisterRequest): Call<RegisterResponse>

    @POST("/api/auth/login")
    fun login(@Body request: LoginRequest): Call<LoginResponse>
}