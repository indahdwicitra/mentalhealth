package com.nhaary.mentalhealthsupportapp.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface HistoryDao {
    @Insert
    suspend fun insertHistory(history: HistoryEntity)

    @Query("SELECT * FROM HistoryEntity ORDER BY id DESC")
    suspend fun getAllHistory(): List<HistoryEntity>

    @Query("SELECT COUNT(*) FROM HistoryEntity")
    suspend fun getHistoryCount(): Int

    @Query("DELETE FROM HistoryEntity WHERE id = (SELECT MIN(id) FROM HistoryEntity)")
    suspend fun deleteOldHistory()
}