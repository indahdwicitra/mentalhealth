package com.nhaary.mentalhealthsupportapp.ui.activity.resultquestionnaire

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.nhaary.mentalhealthsupportapp.MainActivity
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.databinding.ActivityQuestionnaireBinding
import com.nhaary.mentalhealthsupportapp.databinding.ActivityResultQuestionnaireBinding
import com.nhaary.mentalhealthsupportapp.ui.activity.questionnaire.QuestionnaireActivity.Companion.STRESS_LEVEL_KEY
import com.nhaary.mentalhealthsupportapp.ui.activity.questionnaire.QuestionnaireActivity.Companion.TOTAL_KEY

class ResultQuestionnaireActivity : AppCompatActivity() {

    private lateinit var binding: ActivityResultQuestionnaireBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultQuestionnaireBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val score = intent.getIntExtra(TOTAL_KEY, 0)
        val level = intent.getStringExtra(STRESS_LEVEL_KEY)

        val imageRes = when {
            score <= 13 -> R.drawable.image_normal
            score in 14..17 -> R.drawable.image_low_stress
            score in 18..24 -> R.drawable.image_moderate
            score in 25..32 -> R.drawable.image_high_stress
            else -> R.drawable.image_stress
        }

        val totalScoreText = getString(R.string.total_score, score)
        val stressLevelText = getString(R.string.stress_level_questionnaire, level)

        binding.imageIndication.setImageResource(imageRes)

        binding.resultQuestionnaire.text =  "$totalScoreText \n $stressLevelText"

        binding.btnQuestionnaireFinish.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}