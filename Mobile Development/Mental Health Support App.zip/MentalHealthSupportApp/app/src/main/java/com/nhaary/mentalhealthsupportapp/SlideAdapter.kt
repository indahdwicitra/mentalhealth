package com.nhaary.mentalhealthsupportapp

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.nhaary.mentalhealthsupportapp.databinding.ItemImageSliderBinding

class SlideAdapter(private val image: List<Int>) : RecyclerView.Adapter<SlideAdapter.ViewHolder>() {
    inner class ViewHolder (val binding: ItemImageSliderBinding) : RecyclerView.ViewHolder(binding.root){
        fun bind(imageId: Int) {
            Glide.with(binding.imageView.context)
                .load(imageId)
                .into(binding.imageView)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SlideAdapter.ViewHolder {
        val binding = ItemImageSliderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SlideAdapter.ViewHolder, position: Int) {
        val imageId = image[position]
        holder.bind(imageId)
    }

    override fun getItemCount(): Int = image.size

}