package com.nhaary.mentalhealthsupportapp.ui.activity.signin

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.nhaary.mentalhealthsupportapp.MainActivity
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.data.pref.UserPreferences
import com.nhaary.mentalhealthsupportapp.databinding.ActivitySignInBinding
import com.nhaary.mentalhealthsupportapp.ui.activity.signup.SignUpActivity
import com.nhaary.mentalhealthsupportapp.ui.activity.signup.SignUpViewModel
import com.nhaary.mentalhealthsupportapp.ui.setting.SettingViewModel
import com.nhaary.mentalhealthsupportapp.viewmodel.ViewModelFactory

class SignInActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignInBinding
    private lateinit var userPreferences: UserPreferences

    private val signInViewModel by viewModels<SignInViewModel> {
        ViewModelFactory.getInstance(this) }

    private val settingViewModel by viewModels<SettingViewModel> {
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settingViewModel.getThemeSettings().observe(this) { isDarkMode ->
            if (isDarkMode) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }

        userPreferences = UserPreferences(this)

        binding.btnSignIn.setOnClickListener {
            val email = binding.emailFieldInput.text.toString().trim()
            val password = binding.passwordFieldInput.text.toString().trim()

            showLoading(true)
            signInViewModel.login(email, password)
        }
        binding.toRegister.setOnClickListener {
            val intent = Intent(this, SignUpActivity::class.java)
            startActivity(intent)
        }

        observeViewModel()
    }

    private fun observeViewModel() {
        signInViewModel.loginResponse.observe(this) { response ->
            response?.token?.let { token ->
                val name = response.user?.username ?: "Unknown User"
                userPreferences.saveToken(token)
                userPreferences.saveUserName(name)

                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            } ?: run {
                Toast.makeText(this, "Token tidak valid", Toast.LENGTH_SHORT).show()
            }
        }
        signInViewModel.loginError.observe(this) { errorMessage ->
            Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
        }
    }
    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}