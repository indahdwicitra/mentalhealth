    package com.nhaary.mentalhealthsupportapp.data.database.recommend

    import androidx.room.Dao
    import androidx.room.Insert
    import androidx.room.Query
    import androidx.room.Update

    @Dao
    interface RecommendationDao {
        @Insert
        suspend fun insertRecommendation(recommendation: RecommendationEntity)

        @Query("SELECT * FROM recommendations")
        suspend fun getAllRecommendations(): List<RecommendationEntity>

        @Update
        suspend fun updateRecommendation(recommendation: RecommendationEntity)

        @Query("DELETE FROM recommendations WHERE isCompleted = 1")
        suspend fun deleteCompletedRecommendations()


    }