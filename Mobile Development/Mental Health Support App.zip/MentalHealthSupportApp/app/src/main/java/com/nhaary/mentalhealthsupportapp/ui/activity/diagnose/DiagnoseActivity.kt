package com.nhaary.mentalhealthsupportapp.ui.activity.diagnose

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.databinding.ActivityDiagnoseBinding
import com.nhaary.mentalhealthsupportapp.ui.filljurnal.FillJurnalFragment
import com.nhaary.mentalhealthsupportapp.ui.fillpersonality.FillPersonalityFragment

class DiagnoseActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDiagnoseBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDiagnoseBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (savedInstanceState == null) {
            replaceFragment(FillJurnalFragment())
        }
    }

    override fun onBackPressed() {
        val currentFragment = supportFragmentManager.findFragmentById(R.id.fragment_container)
        if (currentFragment is FillJurnalFragment) {
            finish()
        } else {
            super.onBackPressed()
        }
    }

    fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .commit()
    }

}