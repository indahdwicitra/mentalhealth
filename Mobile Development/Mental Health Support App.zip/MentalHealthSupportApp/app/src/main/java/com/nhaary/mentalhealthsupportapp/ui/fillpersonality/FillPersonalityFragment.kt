package com.nhaary.mentalhealthsupportapp.ui.fillpersonality

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.nhaary.mentalhealthsupportapp.MainActivity
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.data.database.recommend.RecommendationDatabase
import com.nhaary.mentalhealthsupportapp.data.database.recommend.RecommendationEntity
import com.nhaary.mentalhealthsupportapp.databinding.FragmentFillPersonalityBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.ByteBuffer
import java.nio.ByteOrder

class FillPersonalityFragment : Fragment() {

    private var _binding: FragmentFillPersonalityBinding? = null
    private val binding get() = _binding!!
    private lateinit var interpreter: Interpreter
    private val recommendations = mutableListOf<Recommendation>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFillPersonalityBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val spinner1: Spinner = binding.professionClassification
        val spinner2: Spinner = binding.hobbyClassification
        val btnPredict: Button = binding.btnFillPersonality

        lifecycleScope.launch {
            loadRecommendations()
        }

        try {
            val modelFile = loadModelFile("model_ml.tflite")
            interpreter = Interpreter(modelFile)
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Error loading model: ${e.message}", Toast.LENGTH_LONG).show()
            Log.e("TFLiteError", "Error loading model", e)
            return
        }

        val professionItems = resources.getStringArray(R.array.profession_list)
        val professionAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            professionItems
        )
        professionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.professionClassification.adapter = professionAdapter

        val hobbyItems = resources.getStringArray(R.array.hobby_list)
        val hobbyAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            hobbyItems
        )
        hobbyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.hobbyClassification.adapter = hobbyAdapter

        binding.btnBack.setOnClickListener {
            parentFragmentManager.popBackStack()
        }
        btnPredict.setOnClickListener {
            lifecycleScope.launch {
                try {
                    val input1 = spinner1.selectedItemPosition
                    val input2 = spinner2.selectedItemPosition

                    if (input1 < 0 || input2 < 0) {
                        Toast.makeText(requireContext(), "Please select both profession and hobby", Toast.LENGTH_SHORT).show()
                        return@launch
                    }

                    if (recommendations.none { it.profession == input1 && it.hobby == input2 }) {
                        Toast.makeText(requireContext(), "No recommendation available for this combination", Toast.LENGTH_SHORT).show()
                        return@launch
                    }

                    val recommendation = getRecommendationFromDataset(input1, input2)
                    if (recommendation != "Recommendation not found.") {

                        val recommendationList = recommendation.split("\n")

                        val database = RecommendationDatabase.getDatabase(requireContext())
                        val recommendationDao = database.recommendationDao()

                        recommendationList.forEach { rec ->
                            val recommendationEntity = RecommendationEntity(
                                profession = input1,
                                hobby = input2,
                                recommendation = rec
                            )
                            recommendationDao.insertRecommendation(recommendationEntity)
                        }

                        val intent = Intent(requireContext(), MainActivity::class.java).apply {
                            putExtra("navigateTo", "todolist")
                        }
                        startActivity(intent)
                        requireActivity().finish()

                        Toast.makeText(requireContext(), "Recommendations successfully saved to database", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(requireContext(), "No recommendation found", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }

    }
    private suspend fun loadRecommendations() {
        withContext(Dispatchers.IO) {
            val inputStream = requireContext().assets.open("activities_dataset.csv")
            val reader = BufferedReader(InputStreamReader(inputStream))
            reader.readLine()  // Skip header

            reader.forEachLine { line ->
                val parts = line.split(",")
                if (parts.size == 4) {
                    val profession = parts[2].toIntOrNull() ?: 0
                    val hobby = parts[3].toIntOrNull() ?: 0
                    val recommendation = parts[1]
                    recommendations.add(Recommendation(profession, hobby, recommendation))
                }
            }
            reader.close()
        }
    }

    private fun getRecommendationFromDataset(profession: Int, hobby: Int): String {
        val matchedRecommendations = recommendations.filter {
            it.profession == profession && it.hobby == hobby
        }.map { it.recommendation }

        return if (matchedRecommendations.isNotEmpty()) {
            matchedRecommendations.joinToString("\n")
        } else {
            "Recommendation not found."
        }
    }


    private fun loadModelFile(fileName: String): ByteBuffer {
        val assetFileDescriptor = requireContext().assets.openFd(fileName)
        val inputStream = assetFileDescriptor.createInputStream()
        val byteArray = inputStream.readBytes()
        val byteBuffer = ByteBuffer.allocateDirect(byteArray.size)
        byteBuffer.order(ByteOrder.nativeOrder())
        byteBuffer.put(byteArray)
        return byteBuffer
    }

    private fun predict(profession: Float, hobby: Float): Float {
        val professionBuffer = TensorBuffer.createFixedSize(intArrayOf(1, 1), DataType.FLOAT32)
        professionBuffer.loadArray(floatArrayOf(profession))

        val hobbyBuffer = TensorBuffer.createFixedSize(intArrayOf(1, 1), DataType.FLOAT32)
        hobbyBuffer.loadArray(floatArrayOf(hobby))

        val outputBuffer = TensorBuffer.createFixedSize(intArrayOf(1, 1), DataType.FLOAT32)

        interpreter.runForMultipleInputsOutputs(
            arrayOf(professionBuffer.buffer, hobbyBuffer.buffer),
            mapOf(0 to outputBuffer.buffer)
        )

        return outputBuffer.floatArray[0]
    }

    override fun onDestroyView() {
        super.onDestroyView()
        if (::interpreter.isInitialized) {
            interpreter.close()
        }
        _binding = null
    }

    data class Recommendation(val profession: Int, val hobby: Int, val recommendation: String)
}