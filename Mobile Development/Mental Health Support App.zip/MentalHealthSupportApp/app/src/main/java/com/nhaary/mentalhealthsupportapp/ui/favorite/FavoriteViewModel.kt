package com.nhaary.mentalhealthsupportapp.ui.favorite

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.nhaary.mentalhealthsupportapp.data.database.article.ArticleEntity
import com.nhaary.mentalhealthsupportapp.data.repository.ArticleRepository

class FavoriteViewModel (private val articleRepository: ArticleRepository): ViewModel() {
    fun getAllFavorites(): LiveData<List<ArticleEntity>> {
        return articleRepository.getAllFavorites()
    }
}