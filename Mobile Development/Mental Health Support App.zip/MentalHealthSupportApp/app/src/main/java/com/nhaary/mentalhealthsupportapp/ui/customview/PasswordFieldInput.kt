package com.nhaary.mentalhealthsupportapp.ui.customview

import android.annotation.SuppressLint
import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatEditText
import com.google.android.material.textfield.TextInputLayout
import com.nhaary.mentalhealthsupportapp.R

@SuppressLint("ViewConstructor")
class PasswordFieldInput @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : AppCompatEditText(context, attrs) {

    init {
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val passwordLayout = (parent.parent as? TextInputLayout)
                val minLength = 8
                if (s.toString().length < minLength) {
                    passwordLayout?.error = context.getString(R.string.password_error, minLength)
                } else {
                    passwordLayout?.error = null
                }
            }

            override fun afterTextChanged(s: Editable?) {
            }

        })
    }


}