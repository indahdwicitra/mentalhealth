package com.nhaary.mentalhealthsupportapp.ui.filljurnal

import android.content.Intent
import androidx.fragment.app.viewModels
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.nhaary.mentalhealthsupportapp.MainActivity
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.databinding.FragmentFillJurnalBinding
import com.nhaary.mentalhealthsupportapp.helper.DiagnoseHelper
import com.nhaary.mentalhealthsupportapp.ui.resultdiagnose.ResultDiagnoseFragment
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FillJurnalFragment : Fragment(), DiagnoseHelper.DiagnoseListener {
    private var _binding: FragmentFillJurnalBinding? = null
    private val binding get() = _binding!!
    private lateinit var diagnoseHelper: DiagnoseHelper

    private val viewModel: FillJurnalViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFillJurnalBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        diagnoseHelper = DiagnoseHelper(context = requireContext(), listener = this)

        with(binding) {
            btnBack.setOnClickListener {
                val intent = Intent(requireContext(), MainActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(intent)
                requireActivity().finish()
            }
            btnDiagnoseDone.setOnClickListener {
                val inputText = diagnoseInput.text.toString().lowercase()
                if (inputText.isNotEmpty()) {
                    val currentDate = getCurrentDate()
                    diagnoseHelper.classify(inputText, currentDate)
                } else {
                    diagnoseInput.error = "Please enter some text"
                }
            }
        }
    }
    override fun onResults(results: String, inferenceTime: Long, date: String, inputText: String) {
        val resultFragment = ResultDiagnoseFragment().apply {
            arguments = Bundle().apply {
                putString(RESULT_KEY, results)
                putLong(INFERENCE_TIME_KEY, inferenceTime)
                putString(DIAGNOSE_DATE_KEY, date)
                putString(JOURNAL_KEY, inputText)
            }
        }

        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, resultFragment)
            .addToBackStack(null)
            .commit()
    }

    override fun onError(error: String) {
        binding.diagnoseInput.error = error
    }

    override fun onDestroyView() {
        super.onDestroyView()
        diagnoseHelper.close()
    }

    private fun getCurrentDate(): String {
        val dateFormat = SimpleDateFormat("HH:mm - MMMM dd, yyyy.", Locale.US)
        return dateFormat.format(Date())
    }

    companion object {
        const val RESULT_KEY = "RESULT_TEXT"
        const val INFERENCE_TIME_KEY = "INFERENCE_TIME"
        const val DIAGNOSE_DATE_KEY = "DIAGNOSE_DATE"
        const val JOURNAL_KEY = "JOURNAL_KEY"
    }
}