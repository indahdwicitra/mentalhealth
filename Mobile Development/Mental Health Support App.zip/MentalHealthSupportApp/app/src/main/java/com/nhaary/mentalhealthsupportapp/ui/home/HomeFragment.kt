package com.nhaary.mentalhealthsupportapp.ui.home

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.SlideAdapter
import com.nhaary.mentalhealthsupportapp.data.adapter.ArticleAdapter
import com.nhaary.mentalhealthsupportapp.databinding.FragmentHomeBinding
import com.nhaary.mentalhealthsupportapp.helper.withDayFormat
import com.nhaary.mentalhealthsupportapp.helper.withMonthFormat
import com.nhaary.mentalhealthsupportapp.helper.withYearFormat
import com.nhaary.mentalhealthsupportapp.ui.activity.detailarticle.DetailArticleActivity
import com.nhaary.mentalhealthsupportapp.ui.activity.diagnose.DiagnoseActivity
import com.nhaary.mentalhealthsupportapp.ui.activity.questionnaire.QuestionnaireActivity
import com.nhaary.mentalhealthsupportapp.viewmodel.ViewModelFactory
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null

    private val binding get() = _binding!!
    private val homeViewModel by viewModels<HomeViewModel>{
        ViewModelFactory.getInstance(requireContext())
    }
    private lateinit var imageSliderAdapter: SlideAdapter
    private lateinit var articleAdapter: ArticleAdapter
    private val handler = Handler(Looper.getMainLooper())
    private var currentPage = 0

    private val slideRunnable = object : Runnable {
        override fun run() {
            if (currentPage == imageSliderAdapter.itemCount) {
                currentPage = 0
            }
            binding.imageSlider.setCurrentItem(currentPage++, true)
            handler.postDelayed(this, 3000)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        setupRecyclerView()
        setupImageSlider()
        setupBtnDiagnose()
        observeViewModel()

        updateCalendar()
    }

    private fun observeViewModel() {
        homeViewModel.fetchArticles()

        homeViewModel.articles.observe(viewLifecycleOwner) { articles ->
            articleAdapter.submitList(articles)
        }

        homeViewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            if (isLoading) {
                binding.progressBar.visibility = View.VISIBLE
                binding.articleHome.visibility = View.GONE
            } else {
                binding.progressBar.visibility = View.GONE
                binding.articleHome.visibility = View.VISIBLE
            }
        }
    }

    private fun setupBtnDiagnose() {
        binding.btnDiagnose.setOnClickListener{
            val intent = Intent(requireContext(), DiagnoseActivity::class.java)
            startActivity(intent)
        }
        binding.btnQuestionnaire.setOnClickListener {
            val intent = Intent(requireContext(), QuestionnaireActivity::class.java)
            startActivity(intent)
        }
    }

    private fun setupImageSlider() {
        homeViewModel.images.observe(viewLifecycleOwner) { images ->
            imageSliderAdapter = SlideAdapter(images)
            binding.imageSlider.adapter = imageSliderAdapter

            handler.post(slideRunnable)
        }
    }

    private fun setupRecyclerView() {
        articleAdapter = ArticleAdapter { article ->
            val intent = Intent(requireContext(), DetailArticleActivity::class.java)
            intent.putExtra(ARTICLE_ID_KEY, article.id)
            startActivity(intent)
        }
        val articleLayoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
        binding.articleHome.layoutManager = articleLayoutManager

        binding.articleHome.adapter = articleAdapter

    }

    private fun updateCalendar() {
        with(binding) {
            calendarToday.text = withDayFormat()
            calendarMonths.text = withMonthFormat()
            calendarYear.text = withYearFormat()
        }
    }


    override fun onDestroyView() {
        super.onDestroyView()
        handler.removeCallbacks(slideRunnable)
        _binding = null
    }

    companion object {
        const val ARTICLE_ID_KEY = "ARTICLE_ID"
    }
}