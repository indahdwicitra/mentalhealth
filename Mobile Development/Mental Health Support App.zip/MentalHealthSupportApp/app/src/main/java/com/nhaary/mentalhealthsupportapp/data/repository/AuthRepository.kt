package com.nhaary.mentalhealthsupportapp.data.repository

import com.nhaary.mentalhealthsupportapp.data.remote.response.LoginRequest
import com.nhaary.mentalhealthsupportapp.data.remote.response.LoginResponse
import com.nhaary.mentalhealthsupportapp.data.remote.response.RegisterRequest
import com.nhaary.mentalhealthsupportapp.data.remote.response.RegisterResponse
import com.nhaary.mentalhealthsupportapp.data.remote.retrofit.ApiService
import retrofit2.Call

class AuthRepository(
    private val apiService: ApiService
){
    fun registerUser(request: RegisterRequest): Call<RegisterResponse> {
        return apiService.registerUser(request)
    }

    fun login(request: LoginRequest): Call<LoginResponse> {
        return apiService.login(request)
    }
}