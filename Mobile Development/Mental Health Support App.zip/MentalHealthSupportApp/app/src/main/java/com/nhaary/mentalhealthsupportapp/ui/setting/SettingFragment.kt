package com.nhaary.mentalhealthsupportapp.ui.setting

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.data.pref.UserPreferences
import com.nhaary.mentalhealthsupportapp.databinding.FragmentSettingBinding
import com.nhaary.mentalhealthsupportapp.dialog.LanguageDialog
import com.nhaary.mentalhealthsupportapp.ui.activity.signin.SignInActivity
import com.nhaary.mentalhealthsupportapp.viewmodel.ViewModelFactory

class SettingFragment : Fragment() {

    private var _binding: FragmentSettingBinding? = null
    private val binding get() = _binding!!

    private lateinit var userPreferences: UserPreferences

    private val settingViewModel by viewModels<SettingViewModel> {
        ViewModelFactory.getInstance(requireContext())
    }
    private var isChanging = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingBinding.inflate(inflater, container, false)
        val root: View = binding.root
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userPreferences = UserPreferences(requireContext())

        setUpView()
    }

    private fun setUpView() {
        with(binding) {
            btnArticlePage.setOnClickListener {
                findNavController().navigate(R.id.navigation_favorite)
            }
            btnChangeLanguage.setOnClickListener {
                showLanguageDialog()
            }
            switchTheme.setOnCheckedChangeListener{ _: CompoundButton?, isChecked: Boolean ->
                if(!isChanging) {
                    settingViewModel.saveThemeSetting(isChecked)
                    updateTheme(isChecked)
                }
            }
            observeViewModel()

            btnLogout.setOnClickListener {

                userPreferences.clearSession()

                val intent = Intent(requireContext(), SignInActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)

                Toast.makeText(requireContext(), "Logout berhasil", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun observeViewModel() {
        settingViewModel.getThemeSettings().observe(viewLifecycleOwner) { isdarkMode: Boolean ->
            isChanging = true
            if(isdarkMode) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                binding.switchTheme.isChecked = true
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                binding.switchTheme.isChecked = false
            }
            isChanging = false
        }
    }

    private fun updateTheme(isDarkMode: Boolean) {
        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }

    private fun showLanguageDialog() {
        LanguageDialog(requireContext()).showLanguageDialog()
    }

    private fun showToast(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }
}