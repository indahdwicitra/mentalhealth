package com.nhaary.mentalhealthsupportapp.ui.activity.questionnaire

import android.content.Intent
import android.os.Bundle
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.nhaary.mentalhealthsupportapp.MainActivity
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.databinding.ActivityQuestionnaireBinding
import com.nhaary.mentalhealthsupportapp.ui.activity.resultquestionnaire.ResultQuestionnaireActivity

class QuestionnaireActivity : AppCompatActivity() {

    private lateinit var binding: ActivityQuestionnaireBinding
    private lateinit var questions: Array<String>
    private lateinit var options: Array<String>
    private var currentIndex = 0
    private val answers = mutableListOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuestionnaireBinding.inflate(layoutInflater)
        setContentView(binding.root)

        questions = resources.getStringArray(R.array.stress_questions)
        options = resources.getStringArray(R.array.answer_options)

        binding.questionText.text =questions[currentIndex]

        setOptions(binding.answerOptions)

        binding.nextButton.setOnClickListener {
            val selectedOption = when (binding.answerOptions.checkedRadioButtonId) {
                R.id.option0 -> 0
                R.id.option1 -> 1
                R.id.option2 -> 2
                R.id.option3 -> 3
                else -> null
            }
            if (selectedOption != null) {
                answers.add(selectedOption)
                currentIndex++
                if (currentIndex < questions.size) {
                    binding.answerOptions.clearCheck()
                    binding.questionText.text = questions[currentIndex]
                } else {
                    moveToResults()
                }
            } else {
                Toast.makeText(this, "Pilih jawaban terlebih dahulu!", Toast.LENGTH_SHORT).show()
            }
        }
        binding.btnBack.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun setOptions(answerOptions: RadioGroup) {
        val optionId = listOf(R.id.option0, R.id.option1, R.id.option2, R.id.option3)
        for (i in options.indices) {
            val radioButton = findViewById<RadioButton>(optionId[i])
            radioButton.text = options[i]
        }
    }
    private fun moveToResults() {
        val score = answers.sum()
        val level = when {
            score <= 13 -> getString(R.string.stress_normal)
            score in 14..17 -> getString(R.string.stress_light)
            score in 18..24 -> getString(R.string.stress_moderate)
            score in 25..32 -> getString(R.string.stress_high)
            else -> getString(R.string.stress_very_high)
        }


        val intent = Intent(this, ResultQuestionnaireActivity::class.java)
        intent.putExtra(TOTAL_KEY, score)
        intent.putExtra(STRESS_LEVEL_KEY, level)
        startActivity(intent)
        finish()
    }

    companion object {
        const val TOTAL_KEY = "TOTAL_SCORE"
        const val STRESS_LEVEL_KEY = "STRESS_LEVEL"
    }
}