package com.nhaary.mentalhealthsupportapp.data.adapter

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.nhaary.mentalhealthsupportapp.data.database.recommend.RecommendationEntity
import com.nhaary.mentalhealthsupportapp.databinding.ItemTodoBinding

class TodoListAdapter (
    val recommendations: MutableList<RecommendationEntity>,
    private val onRecommendationStatusChanged: (RecommendationEntity) -> Unit,
    private val onItemMovedToCompleted: (RecommendationEntity) -> Unit,
    private val onItemMovedToPending: (RecommendationEntity) -> Unit
) : RecyclerView.Adapter<TodoListAdapter.RecommendationViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecommendationViewHolder {
        val binding = ItemTodoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecommendationViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecommendationViewHolder, position: Int) {
        val recommendation = recommendations[position]
        holder.bind(recommendation, position)
    }

    override fun getItemCount(): Int = recommendations.size

    fun updateRecommendations(updatedRecommendations: List<RecommendationEntity>) {
        recommendations.clear()
        recommendations.addAll(updatedRecommendations)
        notifyDataSetChanged()
    }

    fun moveItem(position: Int, toCompleted: Boolean) {
        val recommendation = recommendations.removeAt(position)
        notifyItemRemoved(position)

        recommendation.isCompleted = toCompleted
        recommendations.add(recommendation)
        notifyItemInserted(recommendations.size - 1)
    }

    inner class RecommendationViewHolder(private val binding: ItemTodoBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(recommendation: RecommendationEntity, position: Int) {
            binding.checkboxTodo.text = recommendation.recommendation

            binding.checkboxTodo.setOnCheckedChangeListener(null)
            binding.checkboxTodo.isChecked = recommendation.isCompleted

            binding.checkboxTodo.paintFlags = if (recommendation.isCompleted) {
                binding.checkboxTodo.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            } else {
                binding.checkboxTodo.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            }

            binding.checkboxTodo.setOnCheckedChangeListener { _, isChecked ->
                recommendation.isCompleted = isChecked
                onRecommendationStatusChanged(recommendation)

                if (isChecked) {
                    onItemMovedToCompleted(recommendation)
                } else {
                    onItemMovedToPending(recommendation)
                }
            }
        }
    }
}