package com.nhaary.mentalhealthsupportapp.ui.todolist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.data.adapter.TodoListAdapter
import com.nhaary.mentalhealthsupportapp.data.database.recommend.RecommendationDatabase
import com.nhaary.mentalhealthsupportapp.data.database.recommend.RecommendationEntity
import com.nhaary.mentalhealthsupportapp.data.pref.UserPreferences
import com.nhaary.mentalhealthsupportapp.databinding.FragmentTodolistBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TodoListFragment : Fragment() {
    private lateinit var recyclerViewPending: RecyclerView
    private lateinit var recyclerViewCompleted: RecyclerView
    private lateinit var adapterPending: TodoListAdapter
    private lateinit var adapterCompleted: TodoListAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = FragmentTodolistBinding.inflate(inflater, container, false)
        recyclerViewPending = binding.recyclerviewTodolistPending
        recyclerViewCompleted = binding.recyclerviewTodolistCompleted

        val userPreferences = UserPreferences(requireContext())
        val userName = userPreferences.getUserName()
        binding.greetingUser.text = getString(R.string.greeting, userName)

        val tvTime: TextView = binding.tvTime
        val tvDate: TextView = binding.tvDate
        val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        val date = SimpleDateFormat("EEE, MMM dd", Locale.getDefault()).format(Date())
        tvTime.text = time
        tvDate.text = date

        lifecycleScope.launch {
            val recommendations = getRecommendationsFromDatabase()
            setupRecyclerViews(recommendations)
        }

        binding.deleteActivityComplete.setOnClickListener {
            deleteAllCompletedRecommendations()
        }

        return binding.root
    }

    private suspend fun getRecommendationsFromDatabase(): List<RecommendationEntity> {
        val database = RecommendationDatabase.getDatabase(requireContext())
        val recommendationDao = database.recommendationDao()
        return withContext(Dispatchers.IO) {
            recommendationDao.getAllRecommendations()
        }
    }

    private fun setupRecyclerViews(recommendations: List<RecommendationEntity>) {
        adapterPending = TodoListAdapter(
            recommendations.filter { !it.isCompleted }.toMutableList(),
            { recommendation -> updateRecommendationStatus(recommendation) },
            { recommendation -> moveItemToCompleted(recommendation) },
            { recommendation -> moveItemToPending(recommendation) }
        )
        recyclerViewPending.layoutManager = LinearLayoutManager(requireContext())
        recyclerViewPending.adapter = adapterPending

        adapterCompleted = TodoListAdapter(
            recommendations.filter { it.isCompleted }.toMutableList(),
            { recommendation -> updateRecommendationStatus(recommendation) },
            { recommendation -> moveItemToCompleted(recommendation) },
            { recommendation -> moveItemToPending(recommendation) }
        )
        recyclerViewCompleted.layoutManager = LinearLayoutManager(requireContext())
        recyclerViewCompleted.adapter = adapterCompleted
    }

    private fun moveItemToCompleted(recommendation: RecommendationEntity) {
        val position = adapterPending.recommendations.indexOf(recommendation)
        if (position != -1) {
            adapterPending.recommendations.removeAt(position)
            adapterPending.notifyItemRemoved(position)

            recommendation.isCompleted = true
            adapterCompleted.recommendations.add(recommendation)
            adapterCompleted.notifyItemInserted(adapterCompleted.recommendations.size - 1)

            updateRecommendationStatus(recommendation)
        }
    }

    private fun moveItemToPending(recommendation: RecommendationEntity) {
        val position = adapterCompleted.recommendations.indexOf(recommendation)
        if (position != -1) {
            adapterCompleted.recommendations.removeAt(position)
            adapterCompleted.notifyItemRemoved(position)

            recommendation.isCompleted = false
            adapterPending.recommendations.add(recommendation)
            adapterPending.notifyItemInserted(adapterPending.recommendations.size - 1)

            updateRecommendationStatus(recommendation)
        }
    }

    private fun updateRecommendationStatus(recommendation: RecommendationEntity) {
        lifecycleScope.launch(Dispatchers.IO) {
            val database = RecommendationDatabase.getDatabase(requireContext())
            val recommendationDao = database.recommendationDao()
            recommendationDao.updateRecommendation(recommendation)
        }
    }

    private fun deleteAllCompletedRecommendations() {
        lifecycleScope.launch {
            val database = RecommendationDatabase.getDatabase(requireContext())
            val recommendationDao = database.recommendationDao()

            withContext(Dispatchers.IO) {
                recommendationDao.deleteCompletedRecommendations()
            }

            adapterCompleted.recommendations.clear()
            adapterCompleted.notifyDataSetChanged()
        }
    }
}