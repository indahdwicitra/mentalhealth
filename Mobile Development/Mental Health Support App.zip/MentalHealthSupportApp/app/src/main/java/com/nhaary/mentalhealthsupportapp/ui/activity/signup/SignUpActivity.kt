package com.nhaary.mentalhealthsupportapp.ui.activity.signup

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.databinding.ActivitySignUpBinding
import com.nhaary.mentalhealthsupportapp.ui.activity.signin.SignInActivity
import com.nhaary.mentalhealthsupportapp.viewmodel.ViewModelFactory

class SignUpActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySignUpBinding

    private val signUpViewModel by viewModels<SignUpViewModel> {
        ViewModelFactory.getInstance(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSignUp.setOnClickListener {
            val username = binding.usernameFieldInput.text.toString().trim()
            val email = binding.emailFieldInput.text.toString().trim()
            val password = binding.passwordFieldInput.text.toString().trim()

            signUpViewModel.registerUser(username, email, password)
        }

        signUpViewModel.signUpResponse.observe(this) { response ->
            if (response != null) {
                Toast.makeText(this, "Registrasi berhasil", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, SignInActivity::class.java))
                finish()
            }
        }
        signUpViewModel.signUpError.observe(this) { errorMsg ->
            Toast.makeText(this, "Gagal registrasi: $errorMsg", Toast.LENGTH_SHORT).show()
        }

    }
}