package com.nhaary.mentalhealthsupportapp.ui.activity.signup

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.nhaary.mentalhealthsupportapp.data.remote.response.RegisterRequest
import com.nhaary.mentalhealthsupportapp.data.remote.response.RegisterResponse
import com.nhaary.mentalhealthsupportapp.data.repository.AuthRepository
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SignUpViewModel (private val authRepository: AuthRepository): ViewModel(){

    private val _signUpResponse = MutableLiveData<RegisterResponse?>()
    val signUpResponse: LiveData<RegisterResponse?> get() = _signUpResponse

    private val _signUpError = MutableLiveData<String>()
    val signUpError: LiveData<String> get() = _signUpError

    fun registerUser(username: String, email: String, password: String) {
        val request = RegisterRequest(username, email, password)
        authRepository.registerUser(request).enqueue(object : Callback<RegisterResponse> {
            override fun onResponse(call: Call<RegisterResponse>, response: Response<RegisterResponse>) {
                if (response.isSuccessful) {
                    _signUpResponse.value = response.body()
                } else {
                    _signUpError.value = "Registrasi gagal, email sudah terdaftar"
                }
            }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                _signUpError.value = t.message
            }
        })
    }
}