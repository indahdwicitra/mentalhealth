package com.nhaary.mentalhealthsupportapp.data.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.data.remote.response.DataItem
import com.nhaary.mentalhealthsupportapp.databinding.CardArticleBinding

class ArticleAdapter (private val onClick: (DataItem) -> Unit) : ListAdapter<DataItem, ArticleAdapter.ArticleViewHolder>(DIFF_CALLBACK) {

    class ArticleViewHolder(val binding: CardArticleBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(article: DataItem, onClick: (DataItem) -> Unit){
            binding.titleArticle.text = article.title
            binding.descriptionArticle.text = article.content
            Glide.with(binding.imageItem.context)
                .load(article.imageUrl)
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.broken_image)
                .into(binding.imageItem)
            itemView.setOnClickListener {
                onClick(article)
            }
        }
    }
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ArticleViewHolder {
        val binding = CardArticleBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ArticleViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ArticleViewHolder, position: Int) {
        val article = getItem(position)
        holder.bind(article, onClick)
    }

    companion object {
        val DIFF_CALLBACK = object : DiffUtil.ItemCallback<DataItem>() {
            override fun areItemsTheSame(oldItem: DataItem, newItem: DataItem): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: DataItem, newItem: DataItem): Boolean {
                return oldItem == newItem
            }
        }
    }
}