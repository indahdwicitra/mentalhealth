package com.nhaary.mentalhealthsupportapp.data.repository

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.nhaary.mentalhealthsupportapp.data.database.article.ArticleDao
import com.nhaary.mentalhealthsupportapp.data.database.article.ArticleEntity
import com.nhaary.mentalhealthsupportapp.data.remote.response.ArticleDetailResponse
import com.nhaary.mentalhealthsupportapp.data.remote.response.ArticleResponse
import com.nhaary.mentalhealthsupportapp.data.remote.retrofit.ApiService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ArticleRepository private constructor(
    private val apiService: ApiService,
    private val articleDao: ArticleDao
) {

    fun getArticles(onSuccess: (ArticleResponse) -> Unit, onError: (String) -> Unit) {
        apiService.getArticles().enqueue(object : Callback<ArticleResponse> {
            override fun onResponse(call: Call<ArticleResponse>, response: Response<ArticleResponse>) {
                if (response.isSuccessful) {
                    response.body()?.let { onSuccess(it) }
                } else {
                    onError("Error: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<ArticleResponse>, t: Throwable) {
                onError("Failure: ${t.message}")
            }
        })
    }

    suspend fun getArticleDetails(articleId: Int): Response<ArticleDetailResponse> {
        return apiService.getArticleDetails(articleId)
    }

    fun getFavoriteById(id: Int): LiveData<ArticleEntity?> {
        return articleDao.getFavoriteById(id)
    }

    suspend fun insertFavorite(article: ArticleEntity) {
        articleDao.insertFavorite(article)
    }

    suspend fun deleteFavorite(article: ArticleEntity) {
        articleDao.deleteFavorite(article)
    }

    fun getAllFavorites(): LiveData<List<ArticleEntity>> {
        return articleDao.getAllFavorites()
    }



    companion object {
        @Volatile
        private var instance: ArticleRepository? = null

        fun getInstance(
            apiService: ApiService,
            dao: ArticleDao
        ): ArticleRepository {
            return instance ?: synchronized(this) {
                instance ?: ArticleRepository(apiService, dao).also { instance = it }
            }
        }
    }
}