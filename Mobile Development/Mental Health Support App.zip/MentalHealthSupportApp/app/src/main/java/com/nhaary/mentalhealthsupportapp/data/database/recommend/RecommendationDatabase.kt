package com.nhaary.mentalhealthsupportapp.data.database.recommend

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [RecommendationEntity::class], version = 2)
abstract class RecommendationDatabase : RoomDatabase() {
    abstract fun recommendationDao(): RecommendationDao

    companion object {
        @Volatile
        private var INSTANCE: RecommendationDatabase? = null

        fun getDatabase(context: Context): RecommendationDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RecommendationDatabase::class.java,
                    "recommendation_database"
                ).addMigrations(MIGRATION_1_2)
                    .build()
                INSTANCE = instance
                instance
            }
        }
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Tambahkan kolom `isCompleted` dengan nilai default `false`
                database.execSQL("ALTER TABLE recommendations ADD COLUMN isCompleted INTEGER NOT NULL DEFAULT 0")
            }
        }
    }
}