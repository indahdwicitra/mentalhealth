package com.nhaary.mentalhealthsupportapp.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.nhaary.mentalhealthsupportapp.data.database.article.ArticleDao
import com.nhaary.mentalhealthsupportapp.data.database.article.ArticleEntity

@Database(entities = [HistoryEntity::class, ArticleEntity::class], version = 3)
abstract class HistoryDatabase: RoomDatabase() {
    abstract fun historyDao() : HistoryDao
    abstract fun articleDao() : ArticleDao
    companion object {
        @Volatile
        private var INSTANCE: HistoryDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE HistoryEntity ADD COLUMN complaint_data TEXT")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    """
                        CREATE TABLE IF NOT EXISTS favorite_article (
                            id INTEGER PRIMARY KEY NOT NULL,
                            title TEXT NOT NULL,
                            imageUrl TEXT NOT NULL
                        )
                        """
                )
            }
        }


        @JvmStatic
        fun getDatabase(context: Context): HistoryDatabase {
            if (INSTANCE == null){
                synchronized(HistoryDatabase::class.java) {
                    INSTANCE = Room.databaseBuilder(context.applicationContext,
                        HistoryDatabase::class.java, "history_diagnose_database")
                        .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                        .build()
                }
            }
            return INSTANCE as HistoryDatabase
        }
    }
}