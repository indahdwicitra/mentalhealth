package com.nhaary.mentalhealthsupportapp.data.database.recommend

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recommendations")
data class RecommendationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val profession: Int,
    val hobby: Int,
    val recommendation: String,
    var isCompleted: Boolean = false
)
