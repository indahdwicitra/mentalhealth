package com.nhaary.mentalhealthsupportapp.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.nhaary.mentalhealthsupportapp.di.Injection
import com.nhaary.mentalhealthsupportapp.helper.SettingPreferences
import com.nhaary.mentalhealthsupportapp.ui.setting.SettingViewModel

class ViewModelFactory private constructor(
    private val pref: SettingPreferences
): ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(SettingViewModel::class.java) -> SettingViewModel(pref) as T
            else -> throw IllegalArgumentException("ViewModel Tidak diketahui")
        }
    }
    companion object {
        @Volatile
        private var instance: ViewModelFactory? = null
        fun getInstance(context: Context): ViewModelFactory {
            return instance ?: synchronized(this) {
                instance ?: ViewModelFactory(
                    Injection.providePreferences(context)
                ).also { instance = it }
            }
        }
    }
}