package com.nhaary.mentalhealthsupportapp.data.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.nhaary.mentalhealthsupportapp.data.database.article.ArticleEntity
import com.nhaary.mentalhealthsupportapp.databinding.CardFavoriteArticleBinding

class FavoriteAdapter (private val onClick: (ArticleEntity) -> Unit) : ListAdapter<ArticleEntity, FavoriteAdapter.FavoriteViewHolder>(DIFF_CALLBACK) {
    inner class FavoriteViewHolder(
        private val binding: CardFavoriteArticleBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        fun bind (favorite : ArticleEntity) {
            with(binding) {
                titleArticle.text = favorite.title
                Glide.with(imageItem.context)
                    .load(favorite.imageUrl)
                    .into(imageItem)

                itemView.setOnClickListener {
                    onClick(favorite)
                }
            }
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): FavoriteAdapter.FavoriteViewHolder {
        val binding = CardFavoriteArticleBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return FavoriteViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FavoriteAdapter.FavoriteViewHolder, position: Int) {
        val favorite = getItem(position)
        holder.bind(favorite)
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ArticleEntity>() {
            override fun areItemsTheSame(oldItem: ArticleEntity, newItem: ArticleEntity): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: ArticleEntity, newItem: ArticleEntity): Boolean {
                return oldItem == newItem
            }
        }
    }
}