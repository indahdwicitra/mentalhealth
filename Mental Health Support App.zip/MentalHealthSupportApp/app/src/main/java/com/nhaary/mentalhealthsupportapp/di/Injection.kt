package com.nhaary.mentalhealthsupportapp.di

import android.content.Context
import com.nhaary.mentalhealthsupportapp.helper.SettingPreferences
import com.nhaary.mentalhealthsupportapp.helper.dataStore

object Injection {
    /*fun provideRepository(context: Context) : HomeRepository {
        val apiService = ApiConfig.getApiService()
        val database = EventRoomDatabase.getInstance(context)
        val dao = database.eventDao()
        val appExecutor = AppExecutor()
        return HomeRepository.getInstance(apiService, dao, appExecutor)
    }*/
    fun providePreferences(context: Context): SettingPreferences {
        return SettingPreferences.getInstance(context.dataStore)
    }

}