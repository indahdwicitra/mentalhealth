package com.nhaary.mentalhealthsupportapp.data.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.data.History

class ExampleAdapter(private val listhistory: ArrayList<History>) : RecyclerView.Adapter<ExampleAdapter.ListViewHolder>() {
    class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName: TextView = itemView.findViewById(R.id.tv_item_name)

    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ExampleAdapter.ListViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.card_history_item, parent, false)
        return ListViewHolder(view)
    }

    override fun onBindViewHolder(holder: ExampleAdapter.ListViewHolder, position: Int) {
        val (name) = listhistory[position]
        holder.tvName.text = name
    }

    override fun getItemCount(): Int = listhistory.size
}