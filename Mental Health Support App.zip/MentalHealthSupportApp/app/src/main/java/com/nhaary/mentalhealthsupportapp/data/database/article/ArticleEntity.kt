package com.nhaary.mentalhealthsupportapp.data.database.article

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorite_article")
data class ArticleEntity (
    @PrimaryKey(autoGenerate = false)
    var id: Int,
    var title: String,
    val imageUrl: String
)