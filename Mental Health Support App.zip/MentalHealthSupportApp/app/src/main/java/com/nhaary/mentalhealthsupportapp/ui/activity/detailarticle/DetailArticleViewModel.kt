package com.nhaary.mentalhealthsupportapp.ui.activity.detailarticle

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.nhaary.mentalhealthsupportapp.data.database.article.ArticleEntity
import com.nhaary.mentalhealthsupportapp.data.remote.response.ArticleDetailResponse
import com.nhaary.mentalhealthsupportapp.data.repository.ArticleRepository
import kotlinx.coroutines.launch

class DetailArticleViewModel(private val articleRepository: ArticleRepository) : ViewModel() {

    fun getArticleDetails(articleId: Int) = liveData {
        val response = articleRepository.getArticleDetails(articleId)
        emit(response)
    }

    fun getFavoriteId(id: Int): LiveData<ArticleEntity?> {
        return articleRepository.getFavoriteById(id)
    }

    fun insertFavorite(article: ArticleEntity) {
        viewModelScope.launch {
            articleRepository.insertFavorite(article)
        }
    }

    fun deleteFavorite(article: ArticleEntity) {
        viewModelScope.launch {
            articleRepository.deleteFavorite(article)
        }
    }

}