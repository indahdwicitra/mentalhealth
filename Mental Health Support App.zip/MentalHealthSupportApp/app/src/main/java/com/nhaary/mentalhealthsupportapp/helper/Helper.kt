package com.nhaary.mentalhealthsupportapp.helper

import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun withDayFormat(): String {
    val dayFormat = SimpleDateFormat("EEEE, dd", Locale.getDefault())
    return dayFormat.format(Date())
}
fun withMonthFormat(): String {
    val dayFormat = SimpleDateFormat("MMMM", Locale.getDefault())
    return dayFormat.format(Date())
}
fun withYearFormat(): String {
    val dayFormat = SimpleDateFormat("yyyy", Locale.getDefault())
    return dayFormat.format(Date())
}