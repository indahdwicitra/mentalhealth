package com.nhaary.mentalhealthsupportapp.data.database

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize


@Entity
@Parcelize
data class HistoryEntity (
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    var id: Int = 0,
    @ColumnInfo(name = "data_percentage")
    var dataPercentage: String? = null,
    @ColumnInfo(name = "level_stress")
    var levelStress: String? = null,
    @ColumnInfo(name = "date")
    var date: String? = null,
    @ColumnInfo(name = "inference_time")
    var inferenceTime: String? = null,
    @ColumnInfo(name = "complaint_data")
    var complaintData: String? = null
) : Parcelable