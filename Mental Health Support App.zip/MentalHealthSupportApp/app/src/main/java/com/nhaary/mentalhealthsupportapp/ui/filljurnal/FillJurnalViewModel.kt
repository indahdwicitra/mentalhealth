package com.nhaary.mentalhealthsupportapp.ui.filljurnal

import androidx.lifecycle.ViewModel

class FillJurnalViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}