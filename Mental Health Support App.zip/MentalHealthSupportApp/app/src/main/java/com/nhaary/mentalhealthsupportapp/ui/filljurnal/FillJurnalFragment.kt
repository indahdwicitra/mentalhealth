package com.nhaary.mentalhealthsupportapp.ui.filljurnal

import android.content.Intent
import androidx.fragment.app.viewModels
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.nhaary.mentalhealthsupportapp.MainActivity
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.databinding.FragmentFillJurnalBinding
import com.nhaary.mentalhealthsupportapp.helper.DiagnoseHelper
import com.nhaary.mentalhealthsupportapp.ui.resultdiagnose.ResultDiagnoseFragment

class FillJurnalFragment : Fragment(), DiagnoseHelper.DiagnoseListener {
    private var _binding: FragmentFillJurnalBinding? = null
    private val binding get() = _binding!!
    private lateinit var diagnoseHelper: DiagnoseHelper

    private val viewModel: FillJurnalViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFillJurnalBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        diagnoseHelper = DiagnoseHelper(context = requireContext(), listener = this)

        with(binding) {
            btnBack.setOnClickListener {
                parentFragmentManager.popBackStack()
            }
            btnDiagnoseDone.setOnClickListener {
                val inputText = diagnoseInput.text.toString().lowercase()
                if (inputText.isNotEmpty()) {
                    diagnoseHelper.classify(inputText)
                } else {
                    diagnoseInput.error = "Please enter some text"
                }
            }
        }
    }
    override fun onResults(results: String, inferenceTime: Long) {
        val resultFragment = ResultDiagnoseFragment().apply {
            arguments = Bundle().apply {
                putString("RESULT_TEXT", results)
                putLong("INFERENCE_TIME", inferenceTime)
            }
        }

        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, resultFragment)
            .addToBackStack(null)
            .commit()
    }

    override fun onError(error: String) {
        binding.diagnoseInput.error = error
    }

    override fun onDestroyView() {
        super.onDestroyView()
        diagnoseHelper.close()
    }
}