package com.nhaary.mentalhealthsupportapp.ui.fillpersonality

import androidx.lifecycle.ViewModel

class FillPersonalityViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}