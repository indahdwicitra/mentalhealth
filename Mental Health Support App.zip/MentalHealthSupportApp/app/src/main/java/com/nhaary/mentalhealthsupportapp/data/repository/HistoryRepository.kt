package com.nhaary.mentalhealthsupportapp.data.repository

import com.nhaary.mentalhealthsupportapp.data.database.HistoryDao
import com.nhaary.mentalhealthsupportapp.data.database.HistoryEntity

class HistoryRepository(private val historyDao: HistoryDao) {

    suspend fun getAllHistory(): List<HistoryEntity> {
        return historyDao.getAllHistory()
    }

    suspend fun getHistoryCount(): Int {
        return historyDao.getHistoryCount()
    }

    suspend fun deleteOldHistory() {
        historyDao.deleteOldHistory()
    }
}