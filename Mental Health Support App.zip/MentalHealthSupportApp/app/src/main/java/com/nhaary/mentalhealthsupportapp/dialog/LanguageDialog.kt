package com.nhaary.mentalhealthsupportapp.dialog

import android.app.Activity
import android.content.Context
import androidx.appcompat.app.AlertDialog
import com.nhaary.mentalhealthsupportapp.R
import java.util.Locale

class LanguageDialog(private val context: Context) {

    fun showLanguageDialog() {
        val languages = context.resources.getStringArray(R.array.languages)
        val languageCodes = context.resources.getStringArray(R.array.language_codes)
        val selectedLanguageIndex = languageCodes.indexOf(getSavedLanguage())

        val builder = AlertDialog.Builder(context)
        builder.setTitle(context.getString(R.string.title_change_language))
        builder.setSingleChoiceItems(languages, selectedLanguageIndex) { dialog, which ->
            val selectedLanguageCode = languageCodes[which]
            saveLanguage(selectedLanguageCode)
            changeLanguage(selectedLanguageCode)
            dialog.dismiss()
        }
        builder.setNegativeButton(context.getString(R.string.cancel)) { dialog, _ ->
            dialog.dismiss()
        }
        builder.create().show()
    }

    private fun saveLanguage(languageCode: String) {
        val sharedPreferences = context.getSharedPreferences("app_preferences", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("language", languageCode)
        editor.apply()
    }

    private fun getSavedLanguage(): String {
        val sharedPreferences = context.getSharedPreferences("app_preferences", Context.MODE_PRIVATE)
        return sharedPreferences.getString("language", "en") ?: "en"
    }

    private fun changeLanguage(languageCode: String) {

        val locale = Locale(languageCode)
        Locale.setDefault(locale)

        val config = context.resources.configuration
        config.setLocale(locale)
        config.setLayoutDirection(locale)

        context.resources.updateConfiguration(config, context.resources.displayMetrics)
        (context as? Activity)?.recreate()
    }
}