package com.nhaary.mentalhealthsupportapp.ui.history

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.nhaary.mentalhealthsupportapp.data.database.HistoryEntity
import com.nhaary.mentalhealthsupportapp.data.repository.HistoryRepository
import kotlinx.coroutines.launch

class HistoryViewModel (private val repository: HistoryRepository): ViewModel() {

    private val _historyList = MutableLiveData<List<HistoryEntity>>()
    val historyList: LiveData<List<HistoryEntity>> = _historyList

    fun loadHistory() {
        viewModelScope.launch {
            val histories = repository.getAllHistory()
            _historyList.value = histories
        }
    }
}