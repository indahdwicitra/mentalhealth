package com.nhaary.mentalhealthsupportapp.ui.resultdiagnose

import androidx.fragment.app.viewModels
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.databinding.FragmentFillJurnalBinding
import com.nhaary.mentalhealthsupportapp.databinding.FragmentResultDiagnoseBinding

class ResultDiagnoseFragment : Fragment() {

    private var _binding: FragmentResultDiagnoseBinding? = null
    private val binding get() = _binding!!

    private val viewModel: ResultDiagnoseViewModel by viewModels()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentResultDiagnoseBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val resultText = arguments?.getString("RESULT_TEXT") ?: "No result available"
        val inferenceTime = arguments?.getLong("INFERENCE_TIME") ?: 0L

        with(binding) {
            resultDiagnose.text = resultText
            resultInferenceTime.text = "Inference Time: $inferenceTime ms"
        }
    }
}