package com.nhaary.mentalhealthsupportapp.ui.changelang

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ChangeLanguageViewModel : ViewModel() {
    private val _text = MutableLiveData<String>().apply {
        value = "This is Change Language Fragment"
    }
    val text: LiveData<String> = _text
}