package com.nhaary.mentalhealthsupportapp.ui.fillpersonality

import androidx.fragment.app.viewModels
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.databinding.FragmentFillPersonalityBinding
import com.nhaary.mentalhealthsupportapp.ui.activity.diagnose.DiagnoseActivity
import com.nhaary.mentalhealthsupportapp.ui.filljurnal.FillJurnalFragment

class FillPersonalityFragment : Fragment() {

    private var _binding: FragmentFillPersonalityBinding? = null
    private val binding get() = _binding!!

    private val viewModel: FillPersonalityViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFillPersonalityBinding.inflate(inflater, container, false)
        val root: View = binding.root
        return root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val professionItems = resources.getStringArray(R.array.profession_list)
        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            professionItems
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        binding.professionClassification.adapter = adapter

        binding.professionClassification.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selectedItem = parent.getItemAtPosition(position).toString()
                Toast.makeText(requireContext(), "Selected: $selectedItem", Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
            }
        }
        val hobbyItems = resources.getStringArray(R.array.hobby_list)
        val hobbyAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            hobbyItems
        )

        hobbyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.hobbyClassification.adapter = hobbyAdapter

        binding.hobbyClassification.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val selectedHobby = parent.getItemAtPosition(position).toString()
                Toast.makeText(requireContext(), "Hobby Selected: $selectedHobby", Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
            }
        }

        binding.btnBack.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        binding.btnFillPersonality.setOnClickListener {

        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}