package com.nhaary.mentalhealthsupportapp.ui.activity.detailarticle

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.data.database.article.ArticleEntity
import com.nhaary.mentalhealthsupportapp.databinding.ActivityDetailArticleBinding
import com.nhaary.mentalhealthsupportapp.ui.home.HomeFragment.Companion.ARTICLE_ID_KEY
import com.nhaary.mentalhealthsupportapp.viewmodel.ViewModelFactory

class DetailArticleActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailArticleBinding

    private var isFavorite: Boolean = false

    private val detailArticleViewModel by viewModels<DetailArticleViewModel>{
        ViewModelFactory.getInstance(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailArticleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val articleId = intent.getIntExtra(ARTICLE_ID_KEY, 0)

        detailArticleViewModel.getArticleDetails(articleId).observe(this) { response ->
            if (response.isSuccessful) {
                val article = response.body()?.data
                article?.let {
                    binding.tvTitle.text = it.title
                    binding.subtitleCreatedArticle.text = it.createdAt
                    binding.contentArticle.text = it.content
                    Glide.with(this).load(it.imageUrl).into(binding.ivPicture)

                    val title = it.title.toString()
                    val imageUrl = it.imageUrl.toString()
                    val favoriteArticle = ArticleEntity(articleId, title, imageUrl)

                    binding.fabFavorite.setOnClickListener {
                        if (isFavorite) {
                            detailArticleViewModel.deleteFavorite(favoriteArticle)
                            Toast.makeText(this, "Removed from Favorites", Toast.LENGTH_SHORT).show()
                        } else {
                            detailArticleViewModel.insertFavorite(favoriteArticle)
                            Toast.makeText(this, "Added to Favorites", Toast.LENGTH_SHORT).show()
                        }
                        isFavorite = !isFavorite
                        favoriteIcon()
                    }
                }
            } else {
                Toast.makeText(this, "Failed to load article detail", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnBack.setOnClickListener {
            onBackPressed()
        }

        detailArticleViewModel.getFavoriteId(articleId).observe(this) { favorite ->
            isFavorite = favorite != null
            favoriteIcon()
        }

    }
    private fun favoriteIcon() {
        val icon = if (isFavorite) R.drawable.ic_favorite_black_24dp else R.drawable.ic_favorite_border_black_24dp
        binding.fabFavorite.setImageResource(icon)
    }
}