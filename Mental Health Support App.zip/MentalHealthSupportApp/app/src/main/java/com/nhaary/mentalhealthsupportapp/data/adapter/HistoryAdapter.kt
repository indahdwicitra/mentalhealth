package com.nhaary.mentalhealthsupportapp.data.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.data.database.HistoryEntity
import com.nhaary.mentalhealthsupportapp.databinding.CardHistoryItemBinding

class HistoryAdapter(private val title: String) : ListAdapter<HistoryEntity, HistoryAdapter.HistoryViewHolder>(DIFF_CALLBACK) {
    inner class HistoryViewHolder(private val binding: CardHistoryItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(history: HistoryEntity, title: String) {
            with(binding) {
                val context = binding.root.context
                tvItemName.text = title
                historyDate.text = context.getString(R.string.date_string, history.date)
                stressLevel.text = context.getString(R.string.stress_level_string, history.levelStress)
                complaintText.text = context.getString(R.string.complaint_text, history.complaintData)

                val colorHighStress = ContextCompat.getColor(context, R.color.md_theme_error)
                val colorDefault = ContextCompat.getColor(context, R.color.md_theme_onBackground)

                if (history.levelStress.equals("High Stress", ignoreCase = true)) {
                    stressLevel.setTextColor(colorHighStress)
                } else {
                    stressLevel.setTextColor(colorDefault)
                }
            }
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): HistoryViewHolder {
        val binding = CardHistoryItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return HistoryViewHolder(binding)

    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val history = getItem(position)
        holder.bind(history, title)

    }

    override fun getItemCount(): Int = currentList.size

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<HistoryEntity>() {
            override fun areItemsTheSame(oldItem: HistoryEntity, newItem: HistoryEntity): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(oldItem: HistoryEntity, newItem: HistoryEntity): Boolean {
                return oldItem == newItem
            }
        }
    }
}