package com.nhaary.mentalhealthsupportapp.data

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Suppress("DEPRECATED_ANNOTATION")
@Parcelize
data class History(
    val history: String
): Parcelable
