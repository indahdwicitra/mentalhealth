package com.nhaary.mentalhealthsupportapp.ui.changelang

import androidx.fragment.app.viewModels
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.databinding.FragmentChangeLanguageBinding
import com.nhaary.mentalhealthsupportapp.databinding.FragmentSettingBinding

class ChangeLanguageFragment : Fragment() {

    private val viewModel: ChangeLanguageViewModel by viewModels()

    private var _binding: FragmentChangeLanguageBinding? = null
    private val binding get() = _binding!!


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentChangeLanguageBinding.inflate(inflater, container, false)
        val root: View = binding.root
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val bottomNavView = activity?.findViewById<BottomNavigationView>(R.id.nav_view)
        bottomNavView?.menu?.findItem(R.id.navigation_setting)?.isChecked = true

        binding.rgLanguage.setOnCheckedChangeListener { _, checkedId ->
            when (checkedId) {
                R.id.rb_english -> {
                    Toast.makeText(context, "English Selected", Toast.LENGTH_SHORT).show()
                }
                R.id.rb_indonesian -> {
                    Toast.makeText(context, "Indonesian Selected", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}