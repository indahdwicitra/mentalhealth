package com.nhaary.mentalhealthsupportapp.data.repository

import com.nhaary.mentalhealthsupportapp.data.remote.response.ArticleResponse
import com.nhaary.mentalhealthsupportapp.data.remote.retrofit.ApiService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ArticleRepository (private val apiService: ApiService) {

}