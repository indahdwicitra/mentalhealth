package com.nhaary.mentalhealthsupportapp.ui.search

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.activity.addCallback
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.nhaary.mentalhealthsupportapp.MainActivity
import com.nhaary.mentalhealthsupportapp.databinding.FragmentSearchBinding


class SearchFragment : Fragment() {

    private var _binding: FragmentSearchBinding? = null
//    private val searchViewModel: SearchViewModel by viewModels()
    private val binding get() = _binding!!


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSearchBinding.inflate(inflater, container, false)
        val root: View = binding.root
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        /*if (homeEventViewModel.eventListActive.value != null && homeEventViewModel.eventListPassed.value != null){
            setUpData()
        } else {
            if (Network.isConnectionAvailable(requireContext())){
                setUpData()
            } else {
                showNoInternet()
            }
        }*/

        binding.searchView.editText.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                (requireActivity() as MainActivity).hideBottomNav()
            } else {
                (requireActivity() as MainActivity).showBottomNav()
            }
        }

        setUpData()

    }

    private fun setUpData() {

        val layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.rvSearch.layoutManager = layoutManager

        with(binding) {
            searchView.setupWithSearchBar(searchBar)
            searchView.clearFocus()

            searchView.editText.setOnEditorActionListener { _, actionId, _ ->

                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    val query = searchView.text.toString().trim()

                    if (query.isEmpty()) {
                        Toast.makeText(requireContext(), "Tidak Boleh Kosong", Toast.LENGTH_SHORT).show()
                    } else {
                        /*val intent = Intent(requireContext(), SearchActivity::class.java).apply {
                            putExtra(SearchActivity.SEARCH_QUERY, query)
                        }
                        startActivity(intent)*/
                        Toast.makeText(requireContext(), "Berhasil : $query", Toast.LENGTH_SHORT).show()
                        searchView.hide()
                    }
                    true
                } else {
                    false
                }
            }
        }
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner) {
            if (binding.searchView.isShowing) {
                binding.searchView.hide()
            } else {
                isEnabled = false
                requireActivity().onBackPressed()
            }
        }

//        observeViewModel()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}