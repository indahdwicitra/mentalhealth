package com.nhaary.mentalhealthsupportapp.data.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.data.remote.response.DataItem
import com.nhaary.mentalhealthsupportapp.databinding.CardArticleBinding

class ArticleAdapter(private var articles: List<DataItem>) : RecyclerView.Adapter<ArticleAdapter.ArticleViewHolder>() {

    class ArticleViewHolder(val binding: CardArticleBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(review: DataItem){
            binding.titleArticle.text = review.title
            Glide.with(binding.imageItem.context)
                .load(review.imageUrl)
                .placeholder(R.drawable.placeholder)
                .error(R.drawable.broken_image)
                .into(binding.imageItem)
        }
    }
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ArticleViewHolder {
        val binding = CardArticleBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ArticleViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ArticleViewHolder, position: Int) {
        val article = articles[position]
        holder.bind(article)
    }

    override fun getItemCount(): Int = articles.size

    fun updateArticles(newArticles: List<DataItem>) {
        articles = newArticles
        notifyDataSetChanged()
    }
}