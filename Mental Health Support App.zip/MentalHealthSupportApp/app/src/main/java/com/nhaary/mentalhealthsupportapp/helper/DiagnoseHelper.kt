package com.nhaary.mentalhealthsupportapp.helper

import android.content.Context
import android.util.Log
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder

class DiagnoseHelper (
    context: Context,
    val modelName: String = "emotion_model.tflite",
    var listener: DiagnoseListener? = null
) {

    private var interpreter: Interpreter? = null

    init {
        try {
            interpreter = loadModel(context, modelName)
            Log.d(TAG, "Interpreter berhasil diinisialisasi.")
        } catch (e: Exception) {
            listener?.onError("Error saat inisialisasi model: ${e.message}")
        }
    }

    private fun loadModel(context: Context, modelName: String): Interpreter {
        val modelFile = context.assets.open(modelName).use { it.readBytes() }
        val buffer = ByteBuffer.allocateDirect(modelFile.size).apply {
            order(ByteOrder.nativeOrder())
            put(modelFile)
        }
        return Interpreter(buffer)
    }

    fun classify(inputText: String) {
        if (interpreter == null) {
            listener?.onError("Model belum diinisialisasi.")
            return
        }

        val inputTensor = prepareInputData(inputText)
        val outputTensor = Array(1) { FloatArray(3) }

        try {
            val startTime = System.nanoTime()
            interpreter?.run(inputTensor, outputTensor)
            val endTime = System.nanoTime()

            val inferenceTime = (endTime - startTime) / 1_000_000
            val result = formatResults(outputTensor[0])
            listener?.onResults(result, inferenceTime)
        } catch (e: Exception) {
            listener?.onError("Error saat menjalankan model: ${e.message}")
        }
    }

    private fun prepareInputData(inputText: String): Array<IntArray> {
        val maxLength = 100

        val tokenized = inputText.split(" ").map { (it.hashCode() % 1000) }

        val padded = IntArray(maxLength) { 0 }
        tokenized.take(maxLength).forEachIndexed { index, value ->
            padded[index] = value
        }

        return arrayOf(padded)
    }

    private fun formatResults(probabilities: FloatArray): String {
        val stressLevels = listOf("Low Stress", "Medium Stress", "High Stress")
        val total = probabilities.sum()
        val percentages = probabilities.map { it / total * 100 }

        val maxIndex = probabilities.indices.maxByOrNull { probabilities[it] } ?: 0

        val resultString = StringBuilder()
        stressLevels.forEachIndexed { index, level ->
            resultString.append("$level: ${"%.2f".format(percentages[index])}%\n")
        }
        resultString.append("\nPredicted Stress Level: ${stressLevels[maxIndex]}")

        return resultString.toString()
    }

    fun close() {
        interpreter?.close()
    }

    companion object {
        private const val TAG = "DiagnoseHelper"
    }

    interface DiagnoseListener {
        fun onError(error: String)
        fun onResults(results: String, inferenceTime: Long)
    }
}