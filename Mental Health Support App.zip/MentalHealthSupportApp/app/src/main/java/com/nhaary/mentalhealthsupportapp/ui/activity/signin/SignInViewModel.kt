package com.nhaary.mentalhealthsupportapp.ui.activity.signin

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.nhaary.mentalhealthsupportapp.data.remote.response.LoginRequest
import com.nhaary.mentalhealthsupportapp.data.remote.response.LoginResponse
import com.nhaary.mentalhealthsupportapp.data.repository.AuthRepository
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SignInViewModel(private val authRepository: AuthRepository) : ViewModel() {
    private val _loginResponse = MutableLiveData<LoginResponse?>()
    val loginResponse: LiveData<LoginResponse?> get() = _loginResponse

    private val _loginError = MutableLiveData<String>()
    val loginError: LiveData<String> get() = _loginError

    fun login(email: String, password: String) {
        val request = LoginRequest(email, password)
        authRepository.login(request).enqueue(object : Callback<LoginResponse> {
            override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                if (response.isSuccessful) {
                    _loginResponse.value = response.body()
                } else {
                    _loginError.value = "Login gagal. Periksa email dan password"
                }
            }

            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                _loginError.value = t.message
            }
        })
    }
}