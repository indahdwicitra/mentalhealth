package com.nhaary.mentalhealthsupportapp.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.nhaary.mentalhealthsupportapp.R

class HomeViewModel : ViewModel() {

    private val _images = MutableLiveData<List<Int>>()
    val images: LiveData<List<Int>> get() = _images

    init {
        _images.value = listOf(R.drawable.image1, R.drawable.image2, R.drawable.image3)
    }

}