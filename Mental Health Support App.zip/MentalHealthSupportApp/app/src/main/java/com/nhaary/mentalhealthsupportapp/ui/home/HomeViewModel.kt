package com.nhaary.mentalhealthsupportapp.ui.home

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.data.Result
import com.nhaary.mentalhealthsupportapp.data.remote.response.ArticleResponse
import com.nhaary.mentalhealthsupportapp.data.remote.response.DataItem
import com.nhaary.mentalhealthsupportapp.data.remote.retrofit.ApiConfig
import com.nhaary.mentalhealthsupportapp.data.repository.ArticleRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.HttpException
import retrofit2.Response

class HomeViewModel (private val articleRepository: ArticleRepository): ViewModel() {

    private val _articles = MutableLiveData<List<DataItem>>()
    val articles: LiveData<List<DataItem>> get() = _articles

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> get() = _isLoading

    private val _images = MutableLiveData<List<Int>>()
    val images: LiveData<List<Int>> get() = _images

    init {
        _images.value = listOf(R.drawable.image1, R.drawable.image2, R.drawable.image3)
    }

    fun fetchArticles() {
        _isLoading.value = true
        articleRepository.getArticles(
            onSuccess = { response ->
                _articles.value = response.data
                _isLoading.value = false
            },
            onError = { error ->
                _isLoading.value = false
            }
        )
    }

}
