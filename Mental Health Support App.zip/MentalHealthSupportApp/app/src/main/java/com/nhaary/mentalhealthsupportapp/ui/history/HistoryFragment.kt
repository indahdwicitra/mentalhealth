package com.nhaary.mentalhealthsupportapp.ui.history

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.data.History
import com.nhaary.mentalhealthsupportapp.data.adapter.ExampleAdapter
import com.nhaary.mentalhealthsupportapp.databinding.FragmentHistoryBinding

class HistoryFragment : Fragment() {

    private var _binding: FragmentHistoryBinding? = null
    private val list = ArrayList<History>()
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false)
        val root: View = binding.root
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rvHistory.setHasFixedSize(true)

        list.addAll(getListHistory())
        showRecyclerList()
    }
    private fun getListHistory(): ArrayList<History> {
        val dataName = resources.getStringArray(R.array.example_data)
        val listHistory = ArrayList<History>()
        for (i in dataName.indices) {
            val hero = History(dataName[i])
            listHistory.add(hero)
        }
        return listHistory
    }

    private fun showRecyclerList() {
        val listHeroAdapter = ExampleAdapter(list)
        binding.rvHistory.layoutManager = LinearLayoutManager(requireActivity())
        binding.rvHistory.adapter = listHeroAdapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}