package com.nhaary.mentalhealthsupportapp.ui.history

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.nhaary.mentalhealthsupportapp.R
import com.nhaary.mentalhealthsupportapp.data.History
import com.nhaary.mentalhealthsupportapp.data.adapter.HistoryAdapter
import com.nhaary.mentalhealthsupportapp.databinding.FragmentHistoryBinding
import com.nhaary.mentalhealthsupportapp.ui.home.HomeViewModel
import com.nhaary.mentalhealthsupportapp.viewmodel.ViewModelFactory

class HistoryFragment : Fragment() {

    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding!!
    private val historyViewModel by viewModels<HistoryViewModel>{
        ViewModelFactory.getInstance(requireContext())
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false)
        val root: View = binding.root
        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val titleHistory = resources.getString(R.string.title_history)


        val adapter = HistoryAdapter(titleHistory)

        showRecyclerList(adapter)

        historyViewModel.loadHistory()

        historyViewModel.historyList.observe(viewLifecycleOwner) { histories ->
            adapter.submitList(histories)
        }
    }

    private fun showRecyclerList(adapter: HistoryAdapter) {
        binding.rvHistory.layoutManager = LinearLayoutManager(requireActivity())
        binding.rvHistory.setHasFixedSize(true)
        binding.rvHistory.adapter = adapter
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}