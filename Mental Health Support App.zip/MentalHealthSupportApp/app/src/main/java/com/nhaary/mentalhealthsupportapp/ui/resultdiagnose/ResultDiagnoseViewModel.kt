package com.nhaary.mentalhealthsupportapp.ui.resultdiagnose

import androidx.lifecycle.ViewModel

class ResultDiagnoseViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}