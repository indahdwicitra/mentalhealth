package com.nhaary.mentalhealthsupportapp.data.pref

import android.content.Context

class UserPreferences (context: Context) {
    private val preferences = context.getSharedPreferences("UserSession", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_TOKEN = "token"
    }

    fun saveToken(token: String?) {
        token?.let {
            preferences.edit().putString(KEY_TOKEN, it).apply()
        }
    }

    fun getToken(): String? {
        return preferences.getString(KEY_TOKEN, null)
    }

    fun clearSession() {
        preferences.edit().clear().apply()
    }
}