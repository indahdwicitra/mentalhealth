module.exports = {
  up: async (queryInterface, Sequelize) => {
      await queryInterface.createTable('articles', {
          id: {
              type: Sequelize.INTEGER,
              primaryKey: true,
              autoIncrement: true
          },
          title: {
              type: Sequelize.STRING,
              allowNull: false
          },
          slug: {
              type: Sequelize.STRING,
              allowNull: false,
              unique: true
          },
          category: {
              type: Sequelize.STRING,
              allowNull: false
          },
          tags: {
              type: Sequelize.JSON,
              defaultValue: []
          },
          author: {
              type: Sequelize.STRING,
              allowNull: false
          },
          summary: {
              type: Sequelize.TEXT
          },
          content: {
              type: Sequelize.TEXT,
              allowNull: false
          },
          imageUrl: {
              type: Sequelize.STRING
          },
          readingTime: {
              type: Sequelize.STRING
          },
          publishedAt: {
              type: Sequelize.DATE
          },
          isPublished: {
              type: Sequelize.BOOLEAN,
              defaultValue: true
          },
          createdAt: {
              type: Sequelize.DATE,
              allowNull: false
          },
          updatedAt: {
              type: Sequelize.DATE,
              allowNull: false
          }
      });
  },

  down: async (queryInterface, Sequelize) => {
      await queryInterface.dropTable('articles');
  }
};