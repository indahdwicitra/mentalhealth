// src/controllers/contentController.js
const { Article } = require('../models');
const { slugify } = require('../utils/helpers');
const { Op } = require('sequelize');

class ContentController {
    // Get semua artikel dengan filter dan pagination
    static async getArticles(req, res) {
        try {
            const { 
                category, 
                tag, 
                page = 1, 
                limit = 10,
                search
            } = req.query;

            const where = {};
            
            // Filter berdasarkan kategori
            if (category) {
                where.category = category;
            }

            // Filter berdasarkan tag
            if (tag) {
                where.tags = {
                    [Op.like]: `%${tag}%`
                };
            }

            // Pencarian berdasarkan judul atau konten
            if (search) {
                where[Op.or] = [
                    { title: { [Op.like]: `%${search}%` } },
                    { content: { [Op.like]: `%${search}%` } }
                ];
            }

            const offset = (page - 1) * limit;

            const articles = await Article.findAndCountAll({
                where,
                limit: parseInt(limit),
                offset: parseInt(offset),
                order: [['createdAt', 'DESC']]
            });

            res.json({
                status: 'success',
                data: {
                    articles: articles.rows,
                    total: articles.count,
                    currentPage: parseInt(page),
                    totalPages: Math.ceil(articles.count / limit)
                }
            });

        } catch (error) {
            console.error('Error getting articles:', error);
            res.status(500).json({
                status: 'error',
                message: 'Terjadi kesalahan saat mengambil artikel'
            });
        }
    }

    // Get artikel berdasarkan slug
    static async getArticleBySlug(req, res) {
        try {
            const article = await Article.findOne({
                where: { slug: req.params.slug }
            });

            if (!article) {
                return res.status(404).json({
                    status: 'error',
                    message: 'Artikel tidak ditemukan'
                });
            }

            res.json({
                status: 'success',
                data: article
            });

        } catch (error) {
            console.error('Error getting article:', error);
            res.status(500).json({
                status: 'error',
                message: 'Terjadi kesalahan saat mengambil artikel'
            });
        }
    }

    // Membuat artikel baru
    static async createArticle(req, res) {
        try {
            const {
                title,
                category,
                tags,
                author,
                summary,
                content,
                imageUrl,
                readingTime
            } = req.body;

            // Validasi input
            if (!title || !category || !author || !content) {
                return res.status(400).json({
                    status: 'error',
                    message: 'Title, category, author, dan content harus diisi'
                });
            }

            // Generate slug dari title
            const slug = slugify(title);

            // Cek apakah slug sudah ada
            const existingArticle = await Article.findOne({ where: { slug } });
            if (existingArticle) {
                return res.status(400).json({
                    status: 'error',
                    message: 'Artikel dengan judul yang sama sudah ada'
                });
            }

            // Buat artikel baru
            const article = await Article.create({
                title,
                slug,
                category,
                tags,
                author,
                summary,
                content,
                imageUrl,
                readingTime,
                publishedAt: new Date(),
                isPublished: true
            });

            res.status(201).json({
                status: 'success',
                data: article
            });

        } catch (error) {
            console.error('Error creating article:', error);
            res.status(500).json({
                status: 'error',
                message: 'Terjadi kesalahan saat membuat artikel'
            });
        }
    }

    // Update artikel
    static async updateArticle(req, res) {
        try {
            const { slug } = req.params;
            const updateData = req.body;

            const article = await Article.findOne({ where: { slug } });

            if (!article) {
                return res.status(404).json({
                    status: 'error',
                    message: 'Artikel tidak ditemukan'
                });
            }

            // Jika title diupdate, generate slug baru
            if (updateData.title) {
                updateData.slug = slugify(updateData.title);
            }

            await article.update(updateData);

            res.json({
                status: 'success',
                data: article
            });

        } catch (error) {
            console.error('Error updating article:', error);
            res.status(500).json({
                status: 'error',
                message: 'Terjadi kesalahan saat mengupdate artikel'
            });
        }
    }

    // Hapus artikel
    static async deleteArticle(req, res) {
        try {
            const { slug } = req.params;

            const article = await Article.findOne({ where: { slug } });

            if (!article) {
                return res.status(404).json({
                    status: 'error',
                    message: 'Artikel tidak ditemukan'
                });
            }

            await article.destroy();

            res.json({
                status: 'success',
                message: 'Artikel berhasil dihapus'
            });

        } catch (error) {
            console.error('Error deleting article:', error);
            res.status(500).json({
                status: 'error',
                message: 'Terjadi kesalahan saat menghapus artikel'
            });
        }
    }
}

module.exports = ContentController;