// src/routes/contentRoutes.js
const express = require('express');
const router = express.Router();
const ContentController = require('../controllers/contentController');

router.get('/articles', ContentController.getArticles);
router.get('/articles/:slug', ContentController.getArticleBySlug);
router.post('/articles', ContentController.createArticle);
router.put('/articles/:slug', ContentController.updateArticle);
router.delete('/articles/:slug', ContentController.deleteArticle);

module.exports = router;