// src/models/article.js
const { Model, DataTypes } = require('sequelize');
const sequelize = require('../config/database');

class Article extends Model {}

Article.init({
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    title: {
        type: DataTypes.STRING,
        allowNull: false
    },
    slug: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    category: {
        type: DataTypes.STRING,
        allowNull: false
    },
    tags: {
        type: DataTypes.JSON,
        defaultValue: []
    },
    author: {
        type: DataTypes.STRING,
        allowNull: false
    },
    summary: {
        type: DataTypes.TEXT
    },
    content: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    imageUrl: {
        type: DataTypes.STRING
    },
    readingTime: {
        type: DataTypes.STRING
    },
    publishedAt: {
        type: DataTypes.DATE
    },
    isPublished: {
        type: DataTypes.BOOLEAN,
        defaultValue: true
    }
}, {
    sequelize,
    modelName: 'Article',
    tableName: 'articles',
    timestamps: true // Ini akan menambahkan createdAt dan updatedAt
});

module.exports = Article;