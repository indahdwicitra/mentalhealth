// src/app.js
const express = require('express');
const app = express();
const port = process.env.PORT || 8080; // Cloud Run akan menyediakan PORT

app.use(express.json());
// ... sisa kode anda ...

app.listen(port, '0.0.0.0', () => {
    console.log(`Server running on port ${port}`);
});