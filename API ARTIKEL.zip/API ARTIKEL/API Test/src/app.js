const express = require('express');
const contentRoutes = require('./routes/contentRoutes');
const userRoutes = require('./routes/userRoutes');
const errorHandler = require('./middleware/errorHandler');

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());

// Routes
app.use('/api', contentRoutes);
app.use('/api', userRoutes);

// Error handling
app.use((req, res, next) => {
  res.status(404).json({
      status: 'error',
      message: 'Route tidak ditemukan'
  });
});

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
      status: 'error',
      message: 'Terjadi kesalahan internal'
  });
});

app.listen(port, () => {
    console.log(`Server berjalan di http://localhost:${port}`);
});