const users = {
  bookmarks: [],
  readingHistory: [],
  likes: []
};

module.exports = users;