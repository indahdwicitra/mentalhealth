const contents = {
  articles: [
      {
          id: 1,
          title: "Mengenal Anxiety Disorder",
          slug: "mengenal-anxiety-disorder",
          category: "mental_disorders",
          tags: ["anxiety", "mental health", "kesehatan mental"],
          author: "Dr. Sarah Johnson",
          summary: "Panduan lengkap memahami anxiety disorder dan cara mengatasinya",
          content: `Secara garis besar, anxiety disorder adalah gangguan suasana perasaan seperti depresi, sering ada bersamaan dengan depresi, dan bila tidak segera diatasi maka berpotensi memburuk seiring berjalannya waktu.
                    Jika tidak ditangani dengan baik, anxiety disorder dapat mengganggu aktivitas sehari-hari dan menurunkan kualitas hubungan pengidap dengan orang-orang terdekat, bahkan dengan pasangan dan anak-anaknya sendiri.
                    Hingga kini belum ada yang secara pasti berhasil menjelaskan penyebab anxiety disorder. Namun, secara umum ada beberapa faktor yang sangat berpengaruh dalam peningkatan risiko gangguan kecemasan atau anxiety disorder adalah faktor genetik, faktor biologis (senyawa kimia dalam otak), lingkungan, dan stres.
                    Pengobatan anxiety disorder disesuaikan dengan kondisi pasien dan jenis kecemasannya. Namun, secara umum cara mengatasi anxiety disorder adalah kombinasi dari obat (antidepresan, anticemas) dan psikoterapi seperti terapi kognitif perilaku akan memberikan hasil yang baik pada penderita gangguan cemas.
                    Selain itu, menerapkan pola hidup sehat seperti berhenti merokok, berhenti mengkonsumsi kafein, istirahat yang cukup, aktif berolahraga, dan meditasi juga diharapkan dapat membantu meringankan gangguan kecemasan.
                    Perlu diingat, semua program pengobatan anxiety disorder adalah hal yang harus dilakukan secara terukur dan wajib didampingi oleh profesional kesehatan. Pemberian obat-obatan dilakukan di bawah pengawasan profesional kesehatan agar aman bagi pasien, tidak menimbulkan risiko ketergantungan, maupun risiko penyalahgunaan obat.
                    Jika Anda atau kerabat mengalami gejala yang mengarah pada anxiety disorder, segera konsultasikan dengan Psikiatri untuk mendapatkan penanganan medis yang tepat. Tindakan awal ini sangat penting untuk mencegah kondisi yang lebih serius di kemudian hari. Atau Anda bisa memanfaatkan layanan Telekonsultasi yang memungkinkan Anda untuk berkonsultasi dengan dokter secara virtual.
                    Anxiety disorder adalah gangguan kecemasan yang dapat mempengaruhi kehidupan sehari-hari...`,
          imageUrl: "../images/anxiety-disorder.jpeg",
          readingTime: "8 menit",
          publishedAt: "2024-11-19",
          isPublished: true
      },
      {
          id: 2,
          title: "Teknik Mindfulness untuk Pemula",
          slug: "teknik-mindfulness-pemula",
          category: "meditation",
          tags: ["mindfulness", "meditation", "mental health"],
          author: "Maria Chen",
          summary: "Panduan langkah demi langkah untuk memulai praktik mindfulness",
          content: `Mindfulness adalah cara melatih diri untuk memusatkan perhatian dengan cara tertentu. Hal tersebut dapat membantu kamu dalam kehidupan sehari-hari, pekerjaan, hubungan, dan kesejahteraan secara keseluruhan.
                    Jika kamu mengalami pikiran-pikiran yang menimbulkan ketidaknyamanan atau kegelisahan, mungkin ini saatnya mulai melatih mindfulness untuk mendukung kesadaran, yang dapat mengurangi tingkat stres secara signifikan. 
                    Cara Menerapkan Mindfulness
                    Mindfulness dapat kamu capai melalui meditasi. Namun, kamu juga dapat melatih perhatian melalui kehidupan sehari-hari. 
                    Berfokus pada momen saat ini dan menenangkan dialog batin dapat membantu kamu mencapai kesadaran.
                    Beberapa cara yang dapat kamu lakukan untuk melatih mindfulness dalam kehidupan sehari-hari yaitu:
                    •	Perhatikan: Luangkan waktu untuk memperhatikan hal-hal di sekitarmu. Termasuk perasaan, indra, dan pikiran sendiri. Berfokuslah untuk memperlambat dan menikmati hal-hal yang kamu alami.
                    •	Fokus pada saat ini: Daripada memikirkan masa lalu atau mengkhawatirkan masa depan, cobalah untuk hanya menerima apa yang terjadi di depanmu. Hadir pada momen saat ini dapat membantu kamu merasa lebih sadar.
                    •	Cobalah untuk meditasi mindfulness: Latihan meditasi mindfulness secara teratur memiliki manfaat bagi kesehatan fisik dan mental. Cobalah untuk berlatih salah satu dari 5 Jenis Meditasi yang Jarang Diketahui.
                    Mindfulness adalah praktik untuk hadir sepenuhnya di saat ini...`,
          imageUrl: "../images/mindfulness-basic.jpeg",
          readingTime: "10 menit",
          publishedAt: "2024-11-19",
          isPublished: true
      }
  ],
  
  dailyTips: [
      {
          id: 1,
          title: "5 Teknik Pernapasan untuk Meredakan Stress",
          content: "1. Pernapasan diafragma\n 2. Box breathing\n 3. 4-7-8 breathing\n 4. Breath extension\n 5. Relaksasi otot progresif\n",
          category: "stress_management",
          difficulty: "beginner",
          estimatedTime: "5 menit",
          imageUrl: "../images/breathing-technique.jpeg"
      },
      {
          id: 2,
          title: "Tips Self-Care untuk Hari yang Sibuk",
          content: "1. Luangkan 5 menit untuk meditasi\n 2. Minum air yang cukup\n 3. Stretching ringan 4. Mengurangi penggunaan media sosial",
          category: "self_care",
          difficulty: "beginner",
          estimatedTime: "3 menit",
          imageUrl: "../images/self-care-tips.png"
      }
  ],
  
  exercises: [
      {
          id: 1,
          title: "Mindfulness Meditation",
          description: "Latihan mindfulness sederhana untuk pemula",
          category: "meditation",
          duration: "10 menit",
          steps: [
              "Duduk dengan nyaman",
              "Fokus pada pernapasan",
              "Perhatikan pikiran yang muncul"
          ],
          audioUrl: "/audio/mindfulness-guide.mp3",
          imageUrl: "../images/mindfulness.jpeg"
      },
      {
          id: 2,
          title: "Progressive Muscle Relaxation",
          description: "Teknik relaksasi otot untuk mengurangi ketegangan",
          category: "stress_management",
          duration: "15 menit",
          steps: [
              "Berbaring atau duduk dengan nyaman",
              "Mulai dari otot kaki",
              "Tegang dan rileks secara bergantian"
          ],
          audioUrl: "/audio/pmr-guide.mp3",
          imageUrl: "../images/pmr.jpeg"
      }
  ],
  
  resources: [
      {
          id: 1,
          title: "Hotline Kesehatan Mental",
          category: "emergency_contacts",
          content: "Daftar kontak penting untuk bantuan kesehatan mental",
          contacts: [
              {
                  name: "Layanan Kesehatan Mental",
                  phone: "119",
                  available: "24 jam"
              },
              {
                  name: "Konseling Online",
                  phone: "021-1234567",
                  available: "09.00 - 17.00"
              }
          ]
      }
  ]
};

module.exports = contents;