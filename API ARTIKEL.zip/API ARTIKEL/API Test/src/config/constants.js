const CATEGORIES = {
  mental_disorders: "Gangguan Mental",
  stress_management: "Manajemen Stress",
  meditation: "Meditasi",
  self_care: "Perawatan Diri",
  relationships: "Hubungan & Komunikasi",
  emergency_contacts: "Kontak Darurat"
};

module.exports = {
  CATEGORIES
};