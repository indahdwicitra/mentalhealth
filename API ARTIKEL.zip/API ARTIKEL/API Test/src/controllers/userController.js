const users = require('../data/users');

class UserController {
    static addBookmark(req, res) {
        const { userId } = req.params;
        const { contentId, contentType } = req.body;
        
        const bookmark = {
            id: users.bookmarks.length + 1,
            userId,
            contentId,
            contentType,
            createdAt: new Date().toISOString()
        };
        
        users.bookmarks.push(bookmark);
        
        res.status(201).json({
            status: 'success',
            data: bookmark
        });
    }

    static getBookmarks(req, res) {
        const { userId } = req.params;
        const userBookmarks = users.bookmarks.filter(
            bookmark => bookmark.userId === userId
        );
        
        res.json({
            status: 'success',
            data: userBookmarks
        });
    }

    static addReadingHistory(req, res) {
        const { userId } = req.params;
        const { contentId, contentType } = req.body;
        
        const history = {
            id: users.readingHistory.length + 1,
            userId,
            contentId,
            contentType,
            timestamp: new Date().toISOString()
        };
        
        users.readingHistory.push(history);
        
        res.status(201).json({
            status: 'success',
            data: history
        });
    }
}

module.exports = UserController;