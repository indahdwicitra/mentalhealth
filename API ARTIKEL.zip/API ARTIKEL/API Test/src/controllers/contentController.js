const contents = require('../data/content');
const { slugify, paginateData } = require('../utils/helpers');
const { CATEGORIES } = require('../config/constants');

class ContentController {
    static getCategories(req, res) {
        res.json({
            status: 'success',
            data: CATEGORIES
        });
    }

    static getArticles(req, res) {
        const { category, tag, page = 1, limit = 10 } = req.query;
        let filteredArticles = [...contents.articles];
        
        if (category) {
            filteredArticles = filteredArticles.filter(
                article => article.category === category
            );
        }
        
        if (tag) {
            filteredArticles = filteredArticles.filter(
                article => article.tags.includes(tag)
            );
        }
        
        const paginatedData = paginateData(filteredArticles, page, limit);
        
        res.json({
            status: 'success',
            data: paginatedData
        });
    }

    static getArticleBySlug(req, res) {
        const article = contents.articles.find(
            article => article.slug === req.params.slug
        );
        
        if (!article) {
            return res.status(404).json({
                status: 'error',
                message: 'Artikel tidak ditemukan'
            });
        }
        
        res.json({
            status: 'success',
            data: article
        });
    }

    static getDailyTips(req, res) {
        const { category, difficulty } = req.query;
        let filteredTips = [...contents.dailyTips];
        
        if (category) {
            filteredTips = filteredTips.filter(
                tip => tip.category === category
            );
        }
        
        if (difficulty) {
            filteredTips = filteredTips.filter(
                tip => tip.difficulty === difficulty
            );
        }
        
        res.json({
            status: 'success',
            data: filteredTips
        });
    }

    static getExercises(req, res) {
        const { category, duration } = req.query;
        let filteredExercises = [...contents.exercises];
        
        if (category) {
            filteredExercises = filteredExercises.filter(
                exercise => exercise.category === category
            );
        }
        
        if (duration) {
            filteredExercises = filteredExercises.filter(
                exercise => parseInt(exercise.duration) <= parseInt(duration)
            );
        }
        
        res.json({
            status: 'success',
            data: filteredExercises
        });
    }

    static getEmergencyResources(req, res) {
        const resources = contents.resources.filter(
            resource => resource.category === 'emergency_contacts'
        );
        
        res.json({
            status: 'success',
            data: resources
        });
    }

    static createContent(req, res) {
        const { type } = req.params;
        const contentData = req.body;
        
        if (!contents[type]) {
            return res.status(400).json({
                status: 'error',
                message: 'Tipe konten tidak valid'
            });
        }
        
        // Validasi data yang diperlukan
        if (!contentData.title) {
            return res.status(400).json({
                status: 'error',
                message: 'Title is required'
            });
        }
        
        // Generate ID dan tambahkan data
        contentData.id = contents[type].length + 1;
        
        if (type === 'articles') {
            // Generate slug dari title
            contentData.slug = slugify(contentData.title);
            contentData.publishedAt = new Date().toISOString();
            contentData.isPublished = true;
        }
        
        contents[type].push(contentData);
        
        res.status(201).json({
            status: 'success',
            data: contentData
        });
    }

    static getArticleBySlug(req, res) {
        const article = contents.articles.find(
            article => article.slug === req.params.slug
        );
        
        if (!article) {
            return res.status(404).json({
                status: 'error',
                message: 'Artikel tidak ditemukan'
            });
        }
        
        res.json({
            status: 'success',
            data: article
        });
    }
}

module.exports = ContentController;