const express = require('express');
const router = express.Router();
const ContentController = require('../controllers/contentController');

// Definisi routes
router.get('/categories', ContentController.getCategories);
router.get('/articles', ContentController.getArticles);
router.get('/articles/:slug', ContentController.getArticleBySlug);
router.get('/daily-tips', ContentController.getDailyTips);
router.get('/exercises', ContentController.getExercises);
router.get('/emergency-resources', ContentController.getEmergencyResources);
router.post('/content/:type', ContentController.createContent);

module.exports = router;