const express = require('express');
const router = express.Router();
const UserController = require('../controllers/userController');

router.post('/users/:userId/bookmarks', UserController.addBookmark);
router.get('/users/:userId/bookmarks', UserController.getBookmarks);
router.post('/users/:userId/reading-history', UserController.addReadingHistory);

module.exports = router;