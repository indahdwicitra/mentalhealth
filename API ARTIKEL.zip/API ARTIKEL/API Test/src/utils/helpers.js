// Fungsi untuk mengubah string menjadi slug URL
const slugify = (text) => {
  return text
      .toString()
      .toLowerCase()
      .replace(/\s+/g, '-')        // Ganti spasi dengan -
      .replace(/[^\w\-]+/g, '')    // Hapus karakter non-word
      .replace(/\-\-+/g, '-')      // Ganti multiple - dengan single -
      .replace(/^-+/, '')          // Trim - dari awal text
      .replace(/-+$/, '');         // Trim - dari akhir text
};

// Fungsi untuk paginasi
const paginateData = (data, page = 1, limit = 10) => {
  const startIndex = (page - 1) * limit;
  const endIndex = page * limit;
  
  return {
      data: data.slice(startIndex, endIndex),
      total: data.length,
      page: parseInt(page),
      totalPages: Math.ceil(data.length / limit)
  };
};

module.exports = {
  slugify,
  paginateData
};